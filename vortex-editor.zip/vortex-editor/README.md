# Vortex Editor

Editor de vídeo gratuito para Android (uso pessoal). Kotlin + Jetpack Compose + Media3 (ExoPlayer/Transformer).

## Estrutura
```
app/src/main/java/com/vortex/editor/
  MainActivity.kt        navegação simples (início ⇄ editor), tema
  model/Model.kt         Project, Clip, TextItem, AudioItem (serializáveis)
  data/ProjectStore.kt   persistência JSON local
  media/                 MediaUtils, DeviceCaps (consulta de encoders), ExportMath,
                         CompositionBuilder (projeto → Media3 Composition), Preview
  ui/                    HomeScreen, EditorScreen, ExportDialog, EditorViewModel, Theme
.github/workflows/build.yml   compila o APK no GitHub Actions
```

## Compilar no Android Studio
Abra a pasta, aguarde o Gradle sincronizar e rode `Run ▶` (ou `Build > Build APK`).
Requisitos: JDK 17, Android SDK 34. minSdk 29 (Android 10+).

## Compilar sem computador (GitHub Actions)
Veja as instruções na conversa: suba o projeto num repositório e o GitHub gera o APK em **Actions → Artifacts**.

## Instalar
Baixe `app-debug.apk`, abra no celular e permita "instalar de fontes desconhecidas" para o navegador/gerenciador de arquivos.

Veja `STATUS.md` para o que está pronto, parcial e pendente.
