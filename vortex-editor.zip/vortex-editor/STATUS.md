# STATUS — Vortex Editor v0.1.0 (Etapa 1)

> **Aviso honesto:** este código foi escrito, mas **ainda não foi compilado nem testado em aparelho real**.
> Na primeira compilação podem surgir erros de API; envie o log para corrigir.

## Concluído (implementado no código)
| Recurso | Observação |
|---|---|
| Projetos (criar, listar, abrir, excluir) | JSON no armazenamento interno; nada sai do aparelho |
| Salvamento automático | debounce de 0,5 s + salva ao fechar |
| Importar vídeos e fotos | seletor do sistema (SAF), sem permissões extras |
| Linha do tempo (trilha principal + texto + áudio) | zoom, cursor, toque para selecionar/posicionar |
| Cortar/dividir, duplicar, excluir, reordenar, aparar | não destrutivo |
| Velocidade 0,25x–4x | prévia e exportação (tom preservado no áudio) |
| Volume do clipe e do áudio extra | |
| Brilho, contraste, saturação + copiar/colar ajustes | prévia e exportação |
| Texto com início/fim, posição, tamanho, cor, negrito | prévia e exportação |
| Áudio extra (música) | toca desde o início, cortado ao fim do vídeo |
| Desfazer/refazer | até 100 passos, agrupa arrastes de slider |
| Tema escuro (padrão) e claro | |
| Exportação H.264 e HEVC (quando o aparelho tem encoder) | MP4 + AAC, salva em Filmes/VortexEditor |
| Resoluções 360p–4K, FPS 24–120 | só habilita o que o codificador do aparelho anuncia |
| Bitrate por qualidade + estimativa de tamanho | |
| Progresso e cancelamento | |
| Sem marca-d'água, sem anúncios, sem login, sem internet | |

## Parcial
- **Múltiplas trilhas:** só 1 trilha de vídeo/foto, 1 de texto, 1 de áudio. Sem sobreposição de vídeos (PiP) ainda.
- **FPS:** só *reduz* (descarta quadros). Não cria quadros novos; 4K/120 FPS depende de fonte, codec e GPU.
- **Texto:** sem animações, sem fonte própria, sem legendas automáticas. O tamanho no vídeo exportado é aproximado ao da prévia.
- **Exportação:** roda com o app aberto (sem serviço em segundo plano ainda).
- **Prévia:** efeitos de cor aplicados no clipe atual; não há proxy/baixa resolução.
- **Áudio:** se o 1º item da sequência for uma foto, o áudio dos vídeos seguintes pode ser perdido (limitação do Transformer 1.4).
- **Banco de dados:** JSON em vez de Room (menos risco de build nesta etapa).

## Pendente
Keyframes, transições, efeitos (glitch, VHS, blur…), máscaras, chroma key, LUTs, curvas RGB, reverso, congelar quadro,
legendas SRT/automáticas, narração (microfone), equalizador/redução de ruído, detecção de batidas, IA (remoção de fundo,
rastreamento), proxies, retomada de exportação, idiomas além do português, testes instrumentados em aparelhos.

## Licenças das dependências
AndroidX/Jetpack Compose e Media3: Apache 2.0. kotlinx.serialization/coroutines: Apache 2.0.
Nenhuma dependência paga ou com serviço obrigatório.
