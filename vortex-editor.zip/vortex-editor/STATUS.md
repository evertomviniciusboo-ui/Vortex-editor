# STATUS — Vortex Editor v0.2.0 (Etapa 2)

> **Aviso honesto:** o código desta versão foi escrito e revisado, mas **não foi compilado nem testado em aparelho
> real pelo autor** (o ambiente de desenvolvimento não tem Android SDK). A v0.1 compilou e instalou no GitHub Actions.
> A v0.2 adiciona shaders GLSL e APIs novas do Media3: pode haver erros na primeira compilação. Envie o log do Actions.

## Concluído (implementado no código)
| Área | Recurso |
|---|---|
| Projetos | criar, listar, abrir, excluir (com confirmação), salvar automático, formato JSON versionável (projetos da v0.1 abrem) |
| Mídia | importar vídeo/foto/áudio pelo seletor do Android (URIs persistentes), miniaturas, tratamento de arquivo incompatível |
| Timeline | trilha de vídeo/foto + trilha de texto + trilha de áudio, zoom, cursor, tocar para selecionar/posicionar |
| Edição | dividir, aparar, duplicar, excluir, reordenar, **congelar quadro**, velocidade 0,25x–4x, volume, espelhar H/V, preencher/ajustar tela |
| **Transições (15)** | fade preto, flash branco, luz, zoom in/out, deslizar ←→↑↓, giro, shake, impacto, pulso, glitch; duração e "aplicar a todos"; prévia e exportação usam a mesma matemática |
| **Keyframes** | zoom, rotação, posição X/Y (início → fim do clipe, com suavização) e opacidade |
| **Efeitos GLSL (20)** | glitch, aberração cromática, VHS, granulação, desfoque gaussiano, motion blur, zoom blur, bloom, pixelização, espelho, ondas, tremor de câmera, zoom dinâmico, lens flare, vazamento de luz, partículas, retrô, anime, máscara círculo, barras de cinema; vários por clipe, intensidade ajustável, "aplicar a todos" |
| **Cor** | 9 filtros (P&B, sépia, cinematográfico, quente, frio, dramático, desbotado, vívido, negativo), brilho, contraste, saturação, temperatura, vinheta, fade, nitidez, copiar/colar/redefinir |
| **Texto** | tempo, posição, tamanho, cor, negrito, **fundo**, **4 animações** (fade, pop, subir), **5 fontes do sistema**, importar/exportar **SRT** |
| **Áudio** | música, **gravação de narração** (microfone), volume por item, prévia sonora sincronizada, extra cortado ao fim do vídeo |
| Prévia | ExoPlayer + efeitos GLSL + keyframes/transições aplicados na imagem; se a prévia falhar, desliga efeitos e avisa |
| Exportação | MP4 H.264/HEVC + AAC, 360p–4K, 24–120 FPS (só opções que o encoder anuncia), bitrate por qualidade, estimativa de tamanho, atalhos TikTok/YouTube/WhatsApp, progresso real, cancelar, salvar em Filmes/VortexEditor, abrir/compartilhar |
| Geral | desfazer/refazer (100 passos), tema escuro/claro, 6 proporções (9:16, 16:9, 1:1, 4:5, 4:3, 21:9), sem marca-d'água/anúncios/login/internet |
| Qualidade | 11 testes unitários (duração, transições, keyframes, SRT, JSON antigo, tamanhos/bitrates) |

## Parcial / limitações conhecidas
- **Transições não sobrepõem clipes:** são efeitos ao redor do corte (a metade final do clipe A e a inicial do B). Dissolução cruzada real, varredura com máscara e íris exigem composição em duas camadas (planejado).
- **Múltiplas faixas:** 1 de vídeo/foto, 1 de texto, 1 de áudio. Sem sobreposição de vídeos/imagens (PiP, adesivos) ainda.
- **Efeitos** valem para o clipe inteiro (intensidade fixa); animação de intensidade por keyframes ainda não existe.
- **FPS** só reduz o original; não há interpolação de quadros. 4K/120 FPS depende de fonte, codec, GPU e térmica do aparelho.
- **Texto:** só fontes do sistema (sem importar TTF/OTF); tamanho no vídeo exportado é aproximado ao da prévia.
- **Áudio:** música sempre começa em 0 s e toca em sequência; sem fade, equalizador ou redução de ruído. Se o 1º item da sequência for foto, o áudio dos vídeos seguintes pode se perder (limitação do Transformer 1.4).
- **Prévia:** sem proxy/baixa resolução; a hora usada pelos efeitos de movimento (VHS, glitch) pode diferir da exportação.
- **Exportação** roda com o app aberto (sem serviço em segundo plano).
- **Banco de dados:** JSON em vez de Room.

## Pendente
Dissolução cruzada/íris/varredura por máscara, PiP e camadas sobrepostas, chroma key, máscaras livres, LUT .cube, curvas RGB,
reverso, curva de velocidade, keyframes de efeitos/volume, fade/equalizador/redução de ruído, forma de onda, legendas
automáticas (Whisper), remoção de fundo/rastreamento (IA), importar fontes TTF/OTF, adesivos/formas, biblioteca de mídia
com busca/favoritos, duplicar projeto, exportação em segundo plano, WebM, verificação do arquivo exportado (ffprobe),
VTT, idiomas além do português, testes instrumentados.

## Licenças das dependências
AndroidX/Jetpack Compose, Media3 (ExoPlayer/Transformer/Effect), kotlinx.serialization/coroutines: Apache 2.0.
Nenhuma dependência paga, sem serviços obrigatórios e sem rastreamento.
