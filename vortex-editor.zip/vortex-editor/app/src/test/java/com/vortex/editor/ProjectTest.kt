package com.vortex.editor

import com.vortex.editor.media.Codec
import com.vortex.editor.media.ExportMath
import com.vortex.editor.media.Quality
import com.vortex.editor.model.Clip
import com.vortex.editor.model.MediaKind
import com.vortex.editor.model.Project
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectTest {
    private fun video(id: String, dur: Long, speed: Float = 1f) =
        Clip(id, "content://x/$id", MediaKind.VIDEO, dur, speed = speed)

    @Test fun speedChangesDuration() {
        assertEquals(5000L, video("a", 10_000, 2f).durationMs)
        assertEquals(20_000L, video("a", 10_000, 0.5f).durationMs)
    }

    @Test fun locateMapsGlobalTimeToClip() {
        val p = Project("p", "t", clips = listOf(video("a", 4000), video("b", 10_000, 2f)))
        assertEquals(0 to 1000L, p.locate(1000))
        assertEquals(1 to 2000L, p.locate(5000)) // 1s no clipe b a 2x = 2s de mídia
        assertEquals(9000L, p.durationMs)
    }

    @Test fun globalMsRoundTrip() {
        val p = Project("p", "t", clips = listOf(video("a", 4000), video("b", 10_000, 2f)))
        assertEquals(5000L, p.globalMs(1, 2000))
    }

    @Test fun outputSizesAreEven() {
        assertEquals(1080 to 1920, ExportMath.outputSize(9f / 16f, 1080))
        assertEquals(1920 to 1080, ExportMath.outputSize(16f / 9f, 1080))
        assertEquals(2160 to 3840, ExportMath.outputSize(9f / 16f, 2160))
        val (w, h) = ExportMath.outputSize(4f / 5f, 1080)
        assertTrue(w % 2 == 0 && h % 2 == 0)
    }

    @Test fun bitrateAndEstimate() {
        val br = ExportMath.videoBitrate(1920, 1080, 30, Codec.H264, Quality.MEDIUM)
        assertTrue(br in 4_000_000..8_000_000)
        val hevc = ExportMath.videoBitrate(1920, 1080, 30, Codec.HEVC, Quality.MEDIUM)
        assertTrue(hevc < br)
        assertTrue(ExportMath.estimateBytes(10_000, br) > 0)
    }

    @Test fun jsonRoundTrip() {
        val p = Project("p", "Meu", "16:9", clips = listOf(video("a", 3000)))
        val json = Json { encodeDefaults = true }
        assertEquals(p, json.decodeFromString<Project>(json.encodeToString(p)))
    }
}
