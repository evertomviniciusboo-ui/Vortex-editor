package com.vortex.editor.ui

import android.app.Application
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.vortex.editor.media.MediaUtils
import com.vortex.editor.media.previewEffects
import com.vortex.editor.media.previewItem
import com.vortex.editor.model.Clip
import com.vortex.editor.model.MediaKind
import com.vortex.editor.model.Project
import kotlinx.coroutines.delay

@Composable
fun EditorScreen(projectId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val vm: EditorViewModel = viewModel(
        key = projectId,
        factory = viewModelFactory {
            initializer { EditorViewModel(this[APPLICATION_KEY] as Application, projectId) }
        },
    )
    val project by vm.project.collectAsStateWithLifecycle()
    val exo = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(exo) { onDispose { exo.release() } }

    var idx by remember { mutableIntStateOf(0) }
    var posMs by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var dpPerSec by remember { mutableFloatStateOf(60f) }
    var showExport by remember { mutableStateOf(false) }
    var scrubbing by remember { mutableStateOf<Float?>(null) }

    LaunchedEffect(exo) {
        while (true) {
            idx = exo.currentMediaItemIndex
            posMs = exo.currentPosition
            playing = exo.isPlaying
            delay(80)
        }
    }

    LaunchedEffect(vm.message) {
        vm.message?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show(); vm.message = null }
    }

    // Reconstrói a playlist de preview somente quando a estrutura (ids/cortes) muda.
    val structureKey = project.clips.map { Triple(it.id, it.trimStartMs, it.trimEndMs) }
    LaunchedEffect(structureKey) {
        val clips = project.clips
        if (clips.isEmpty()) {
            exo.clearMediaItems()
        } else {
            val i = exo.currentMediaItemIndex.coerceIn(0, clips.lastIndex)
            val p = exo.currentPosition.coerceIn(0L, clips[i].sourceSpanMs)
            exo.setMediaItems(clips.map { previewItem(it) }, i, p)
            exo.prepare()
        }
    }

    val cur = project.clips.getOrNull(idx)
    LaunchedEffect(cur?.id, cur?.speed, cur?.volume, cur?.brightness, cur?.contrast, cur?.saturation) {
        exo.playbackParameters = PlaybackParameters(if (cur != null && cur.kind == MediaKind.VIDEO) cur.speed else 1f)
        exo.volume = (cur?.volume ?: 1f).coerceIn(0f, 1f)
        runCatching { exo.setVideoEffects(previewEffects(cur)) }
    }

    val globalMs = project.globalMs(idx, posMs)
    val total = project.durationMs

    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { MediaUtils.takePersist(ctx, it) }
        if (uris.isNotEmpty()) vm.addMedia(uris)
    }

    BackHandler(onBack = onBack)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(project.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") } },
                actions = {
                    IconButton(onClick = { vm.undo() }, enabled = vm.canUndo) { Icon(Icons.AutoMirrored.Filled.Undo, "Desfazer") }
                    IconButton(onClick = { vm.redo() }, enabled = vm.canRedo) { Icon(Icons.AutoMirrored.Filled.Redo, "Refazer") }
                    Button(
                        onClick = { exo.pause(); showExport = true },
                        enabled = project.clips.isNotEmpty(),
                        modifier = Modifier.padding(end = 8.dp),
                    ) {
                        Icon(Icons.Default.FileDownload, null, Modifier.size(18.dp))
                        Text(" Exportar")
                    }
                },
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            // ---------- Preview ----------
            Box(Modifier.weight(1f).fillMaxWidth().background(Color.Black), contentAlignment = Alignment.Center) {
                Box(Modifier.aspectRatio(project.aspectRatio, matchHeightConstraintsFirst = true).background(Color(0xFF111111))) {
                    AndroidView(
                        factory = { c ->
                            PlayerView(c).apply {
                                useController = false
                                player = exo
                                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                            }
                        },
                        modifier = Modifier.fillMaxSize(),
                    )
                    val density = LocalDensity.current
                    BoxWithConstraints(Modifier.fillMaxSize()) {
                        val frameW = constraints.maxWidth.toFloat()
                        project.texts.filter { globalMs >= it.startMs && globalMs < it.endMs }.forEach { t ->
                            Text(
                                t.text,
                                color = Color(t.color),
                                fontWeight = if (t.bold) FontWeight.Bold else FontWeight.Normal,
                                fontSize = with(density) { (frameW * t.sizePct / 100f).toSp() },
                                textAlign = TextAlign.Center,
                                style = TextStyle(shadow = Shadow(Color.Black, blurRadius = 8f)),
                                modifier = Modifier
                                    .align(BiasAlignment(t.xPct / 50f - 1f, t.yPct / 50f - 1f))
                                    .widthIn(max = maxWidth * 0.9f),
                            )
                        }
                    }
                    if (project.clips.isEmpty()) {
                        Text(
                            "Toque em + para importar\nvídeos ou fotos",
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.align(Alignment.Center),
                        )
                    }
                }
            }

            // ---------- Transporte ----------
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    if (project.clips.isEmpty()) return@IconButton
                    if (playing) exo.pause() else {
                        if (exo.playbackState == Player.STATE_ENDED) exo.seekTo(0, 0L)
                        exo.play()
                    }
                }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Reproduzir/Pausar") }
                Text("${fmt(globalMs)} / ${fmt(total)}", fontSize = 12.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { dpPerSec = (dpPerSec / 1.5f).coerceAtLeast(15f) }) { Icon(Icons.Default.ZoomOut, "Diminuir zoom") }
                IconButton(onClick = { dpPerSec = (dpPerSec * 1.5f).coerceAtMost(400f) }) { Icon(Icons.Default.ZoomIn, "Aumentar zoom") }
                FilledTonalIconButton(onClick = { mediaPicker.launch(arrayOf("video/*", "image/*")) }) {
                    Icon(Icons.Default.Add, "Importar mídia")
                }
            }
            Slider(
                value = scrubbing ?: globalMs.toFloat().coerceAtMost(maxOf(total, 1L).toFloat()),
                onValueChange = { v ->
                    scrubbing = v
                    project.locate(v.toLong())?.let { (i, p) -> exo.seekTo(i, p) }
                },
                onValueChangeFinished = { scrubbing = null },
                valueRange = 0f..maxOf(total, 1L).toFloat(),
                modifier = Modifier.padding(horizontal = 12.dp).height(28.dp),
            )

            // ---------- Linha do tempo ----------
            TimelineView(
                project = project,
                vm = vm,
                playheadMs = globalMs,
                playing = playing,
                dpPerSec = dpPerSec,
                onSeekClip = { i, p -> exo.seekTo(i, p) },
                onSelectText = { tab = 2 },
                onSelectClip = { if (tab == 2 || tab == 3 || tab == 4) tab = 0 },
            )

            // ---------- Abas ----------
            TabRow(selectedTabIndex = tab) {
                listOf("Clipe", "Cor", "Texto", "Áudio", "Projeto").forEachIndexed { i, l ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(l, fontSize = 13.sp) })
                }
            }
            Box(Modifier.height(210.dp).fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp)) {
                when (tab) {
                    0 -> ClipPanel(project, vm, idx, posMs)
                    1 -> ColorPanel(project, vm)
                    2 -> TextPanel(project, vm, globalMs)
                    3 -> AudioPanel(project, vm)
                    else -> ProjectPanel(project, vm)
                }
            }
        }
    }

    if (showExport) {
        ExportDialog(project = project, vm = vm, onDismiss = { showExport = false })
    }
}

@Composable
private fun TimelineView(
    project: Project,
    vm: EditorViewModel,
    playheadMs: Long,
    playing: Boolean,
    dpPerSec: Float,
    onSeekClip: (Int, Long) -> Unit,
    onSelectText: () -> Unit,
    onSelectClip: () -> Unit,
) {
    val scroll = rememberScrollState()
    val density = LocalDensity.current
    var viewW by remember { mutableIntStateOf(0) }
    fun w(ms: Long): Dp = (ms * dpPerSec / 1000f).dp

    LaunchedEffect(playheadMs, playing) {
        if (playing) {
            val x = with(density) { w(playheadMs).toPx() }
            scroll.scrollTo((x - viewW / 2f).toInt().coerceAtLeast(0))
        }
    }

    val primary = MaterialTheme.colorScheme.primary
    Box(
        Modifier.fillMaxWidth().height(132.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .onSizeChanged { viewW = it.width }
            .horizontalScroll(scroll)
    ) {
        Box(Modifier.width(w(maxOf(project.durationMs, 1000L)) + 160.dp).height(124.dp).padding(top = 4.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                // Trilha de vídeo/imagem
                Row {
                    project.clips.forEachIndexed { i, c ->
                        val selected = vm.selectedClipId == c.id
                        Box(
                            Modifier.width(w(c.durationMs)).height(56.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .then(if (selected) Modifier.border(2.dp, primary, RoundedCornerShape(6.dp)) else Modifier)
                                .pointerInput(c.id, dpPerSec) {
                                    detectTapGestures { off ->
                                        vm.selectedClipId = c.id
                                        vm.selectedTextId = null
                                        onSelectClip()
                                        val frac = (off.x / size.width).coerceIn(0f, 1f)
                                        onSeekClip(i, (frac * c.sourceSpanMs).toLong())
                                    }
                                }
                        ) {
                            Thumb(c.uri, c.kind, c.trimStartMs, Modifier.fillMaxSize())
                            Text(
                                (if (c.speed != 1f && c.kind == MediaKind.VIDEO) "${c.speed}x · " else "") + fmt(c.durationMs),
                                fontSize = 10.sp, color = Color.White, maxLines = 1,
                                modifier = Modifier.align(Alignment.BottomStart).background(Color(0x99000000)).padding(horizontal = 3.dp),
                            )
                        }
                    }
                }
                // Trilha de texto
                Box(Modifier.fillMaxWidth().height(28.dp)) {
                    project.texts.forEach { t ->
                        Box(
                            Modifier.offset(x = w(t.startMs)).width(w(t.endMs - t.startMs)).height(28.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (vm.selectedTextId == t.id) primary else MaterialTheme.colorScheme.tertiary)
                                .clickable { vm.selectedTextId = t.id; vm.selectedClipId = null; onSelectText() }
                        ) {
                            Text(t.text, fontSize = 11.sp, maxLines = 1, color = Color.White, modifier = Modifier.padding(horizontal = 4.dp))
                        }
                    }
                }
                // Trilha de áudio
                Box(Modifier.fillMaxWidth().height(28.dp)) {
                    var acc = 0L
                    project.audios.forEach { a ->
                        val len = minOf(a.durationMs, (project.durationMs - acc).coerceAtLeast(0L))
                        if (len > 0) {
                            Box(
                                Modifier.offset(x = w(acc)).width(w(len)).height(28.dp)
                                    .clip(RoundedCornerShape(4.dp)).background(Color(0xFF2E7D6B))
                            ) {
                                Text(a.name, fontSize = 11.sp, maxLines = 1, color = Color.White, modifier = Modifier.padding(horizontal = 4.dp))
                            }
                        }
                        acc += len
                    }
                }
            }
            // Cursor (playhead)
            Box(Modifier.offset(x = w(playheadMs)).width(2.dp).height(120.dp).background(Color.White))
        }
    }
}

@Composable
private fun ActionChip(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    AssistChip(onClick = onClick, label = { Text(label) }, leadingIcon = { Icon(icon, null, Modifier.size(18.dp)) })
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    display: String,
    onChange: (Float) -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 12.sp)
            Text(display, fontSize = 12.sp)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun ClipPanel(project: Project, vm: EditorViewModel, idx: Int, posMs: Long) {
    val clip = project.clips.find { it.id == vm.selectedClipId }
    if (clip == null) {
        Text("Toque em um clipe na linha do tempo para editá-lo.")
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionChip("Dividir", Icons.Default.ContentCut) {
                if (project.clips.getOrNull(idx)?.id == clip.id) vm.splitClip(clip.id, posMs)
                else vm.message = "Posicione o cursor sobre o clipe selecionado."
            }
            ActionChip("Duplicar", Icons.Default.ContentCopy) { vm.duplicateClip(clip.id) }
            ActionChip("Excluir", Icons.Default.Delete) { vm.deleteClip(clip.id) }
            ActionChip("Mover", Icons.Default.ChevronLeft) { vm.moveClip(clip.id, -1) }
            ActionChip("Mover", Icons.Default.ChevronRight) { vm.moveClip(clip.id, 1) }
        }
        if (clip.kind == MediaKind.VIDEO) {
            LabeledSlider("Velocidade", clip.speed, 0.25f..4f, "%.2fx".format(clip.speed)) { v ->
                vm.updateClip(clip.id, "speed:${clip.id}") { it.copy(speed = (Math.round(v * 20f) / 20f)) }
            }
            Text("Aparar: ${fmt(clip.trimStartMs)} → ${fmt(clip.trimEndMs)}", fontSize = 12.sp)
            RangeSlider(
                value = clip.trimStartMs.toFloat()..clip.trimEndMs.toFloat(),
                onValueChange = { r ->
                    val s = r.start.toLong()
                    val e = r.endInclusive.toLong()
                    if (e - s >= 300L) vm.updateClip(clip.id, "trim:${clip.id}") { it.copy(trimStartMs = s, trimEndMs = e) }
                },
                valueRange = 0f..clip.sourceDurationMs.toFloat(),
            )
            LabeledSlider("Volume do clipe", clip.volume, 0f..1.5f, "${(clip.volume * 100).toInt()}%") { v ->
                vm.updateClip(clip.id, "vol:${clip.id}") { it.copy(volume = v) }
            }
            Text("Prévia limita o volume a 100%; a exportação aplica o valor completo.", fontSize = 11.sp)
        } else {
            LabeledSlider("Duração da foto", clip.sourceSpanMs.toFloat(), 500f..15000f, "%.1fs".format(clip.sourceSpanMs / 1000f)) { v ->
                vm.updateClip(clip.id, "dur:${clip.id}") { it.copy(trimEndMs = v.toLong()) }
            }
        }
    }
}

@Composable
private fun ColorPanel(project: Project, vm: EditorViewModel) {
    val clip = project.clips.find { it.id == vm.selectedClipId }
    if (clip == null) {
        Text("Selecione um clipe para ajustar a cor.")
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        LabeledSlider("Brilho", clip.brightness, -1f..1f, "${(clip.brightness * 100).toInt()}") { v ->
            vm.updateClip(clip.id, "br:${clip.id}") { it.copy(brightness = v) }
        }
        LabeledSlider("Contraste", clip.contrast, -1f..1f, "${(clip.contrast * 100).toInt()}") { v ->
            vm.updateClip(clip.id, "ct:${clip.id}") { it.copy(contrast = v) }
        }
        LabeledSlider("Saturação", clip.saturation, -100f..100f, "${clip.saturation.toInt()}") { v ->
            vm.updateClip(clip.id, "sat:${clip.id}") { it.copy(saturation = v) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionChip("Copiar ajustes", Icons.Default.ContentCopy) { vm.copyAdjust(clip) }
            ActionChip("Colar ajustes", Icons.Default.ContentCopy) { vm.pasteAdjust(clip.id) }
            ActionChip("Redefinir", Icons.Default.Delete) {
                vm.updateClip(clip.id) { it.copy(brightness = 0f, contrast = 0f, saturation = 0f) }
            }
        }
    }
}

private val textColors = listOf(
    -1, 0xFFFFEB3B.toInt(), 0xFFFF5252.toInt(), 0xFF40C4FF.toInt(), 0xFF69F0AE.toInt(), 0xFF000000.toInt(),
)

@Composable
private fun TextPanel(project: Project, vm: EditorViewModel, globalMs: Long) {
    val sel = project.texts.find { it.id == vm.selectedTextId }
    val total = maxOf(project.durationMs, 1L).toFloat()
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.addText(globalMs) }) { Text("+ Texto aqui") }
            project.texts.forEach { t ->
                FilterChip(selected = t.id == sel?.id, onClick = { vm.selectedTextId = t.id; vm.selectedClipId = null }, label = { Text(t.text.take(12)) })
            }
        }
        if (sel == null) {
            Text("Adicione um texto no ponto atual da linha do tempo.", fontSize = 12.sp)
            return
        }
        var text by remember(sel.id) { mutableStateOf(sel.text) }
        OutlinedTextField(
            value = text,
            onValueChange = { text = it; vm.updateText(sel.id, "txt:${sel.id}") { t -> t.copy(text = it) } },
            label = { Text("Texto") },
            modifier = Modifier.fillMaxWidth(),
        )
        LabeledSlider("Início", sel.startMs.toFloat(), 0f..total, fmt(sel.startMs)) { v ->
            vm.updateText(sel.id, "ts:${sel.id}") { it.copy(startMs = v.toLong().coerceAtMost(it.endMs - 300L).coerceAtLeast(0L)) }
        }
        LabeledSlider("Fim", sel.endMs.toFloat(), 0f..total, fmt(sel.endMs)) { v ->
            vm.updateText(sel.id, "te:${sel.id}") { it.copy(endMs = v.toLong().coerceAtLeast(it.startMs + 300L)) }
        }
        LabeledSlider("Posição horizontal", sel.xPct, 0f..100f, "${sel.xPct.toInt()}%") { v ->
            vm.updateText(sel.id, "tx:${sel.id}") { it.copy(xPct = v) }
        }
        LabeledSlider("Posição vertical", sel.yPct, 0f..100f, "${sel.yPct.toInt()}%") { v ->
            vm.updateText(sel.id, "ty:${sel.id}") { it.copy(yPct = v) }
        }
        LabeledSlider("Tamanho", sel.sizePct, 2f..20f, "%.1f".format(sel.sizePct)) { v ->
            vm.updateText(sel.id, "tz:${sel.id}") { it.copy(sizePct = v) }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            textColors.forEach { c ->
                Box(
                    Modifier.size(28.dp).clip(CircleShape).background(Color(c))
                        .border(if (c == sel.color) 3.dp else 1.dp, MaterialTheme.colorScheme.primary, CircleShape)
                        .clickable { vm.updateText(sel.id) { it.copy(color = c) } }
                )
            }
            Spacer(Modifier.weight(1f))
            Text("Negrito", fontSize = 12.sp)
            Switch(checked = sel.bold, onCheckedChange = { b -> vm.updateText(sel.id) { it.copy(bold = b) } })
        }
        OutlinedButton(onClick = { vm.deleteText(sel.id) }) {
            Icon(Icons.Default.Delete, null, Modifier.size(18.dp)); Text(" Excluir texto")
        }
    }
}

@Composable
private fun AudioPanel(project: Project, vm: EditorViewModel) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { MediaUtils.takePersist(ctx, it); vm.addAudio(it) }
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Button(onClick = { picker.launch(arrayOf("audio/*")) }) {
            Icon(Icons.Default.MusicNote, null, Modifier.size(18.dp)); Text(" Adicionar música / áudio")
        }
        Text("O áudio extra toca desde o início e é cortado ao fim do vídeo.", fontSize = 11.sp)
        project.audios.forEach { a ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(a.name, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                IconButton(onClick = { vm.deleteAudio(a.id) }) { Icon(Icons.Default.Delete, "Remover áudio") }
            }
            LabeledSlider("Volume", a.volume, 0f..1.5f, "${(a.volume * 100).toInt()}%") { v ->
                vm.updateAudio(a.id, "av:${a.id}") { it.copy(volume = v) }
            }
        }
    }
}

@Composable
private fun ProjectPanel(project: Project, vm: EditorViewModel) {
    var name by remember { mutableStateOf(project.name) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = name,
            onValueChange = { name = it; vm.rename(it.ifBlank { "Projeto" }) },
            label = { Text("Nome do projeto") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Text("Proporção")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("9:16", "16:9", "1:1", "4:5").forEach { a ->
                FilterChip(selected = project.aspect == a, onClick = { vm.setAspect(a) }, label = { Text(a) })
            }
        }
        Text("Projeto salvo automaticamente neste aparelho.", fontSize = 11.sp)
    }
}
