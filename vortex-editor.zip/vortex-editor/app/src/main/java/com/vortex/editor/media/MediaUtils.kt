package com.vortex.editor.media

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.util.LruCache
import com.vortex.editor.model.MediaKind

data class MediaInfo(val kind: MediaKind, val durationMs: Long)

object MediaUtils {
    private val cache = LruCache<String, Bitmap>(48)

    fun takePersist(ctx: Context, uri: Uri) {
        runCatching {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun probe(ctx: Context, uri: Uri): MediaInfo? {
        val type = ctx.contentResolver.getType(uri) ?: ""
        if (type.startsWith("image/")) return MediaInfo(MediaKind.IMAGE, 0L)
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            if (d == null || d <= 0) null else MediaInfo(MediaKind.VIDEO, d)
        } catch (e: Exception) {
            null
        } finally {
            runCatching { r.release() }
        }
    }

    fun displayName(ctx: Context, uri: Uri): String = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    }.getOrNull() ?: "Áudio"

    fun thumbnail(ctx: Context, uri: Uri, kind: MediaKind, atMs: Long): Bitmap? {
        val key = "$uri@${atMs / 1000}"
        cache.get(key)?.let { return it }
        val bmp = runCatching {
            if (kind == MediaKind.IMAGE) {
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                var s = 1
                while (opts.outWidth / s > 480) s *= 2
                val o2 = BitmapFactory.Options().apply { inSampleSize = s }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            } else {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, uri)
                    val f = r.getFrameAtTime(atMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    if (f != null && f.width > 320) {
                        Bitmap.createScaledBitmap(f, 320, (f.height * 320f / f.width).toInt().coerceAtLeast(1), true)
                    } else f
                } finally {
                    runCatching { r.release() }
                }
            }
        }.getOrNull()
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }
}
