package com.vortex.editor.media

import kotlin.math.roundToInt

enum class Codec(val label: String, val mime: String, val bppFactor: Float) {
    H264("H.264 / AVC", "video/avc", 1f),
    HEVC("H.265 / HEVC", "video/hevc", 0.7f),
}

enum class Quality(val label: String, val bpp: Float) {
    LOW("Baixa", 0.05f),
    MEDIUM("Média", 0.09f),
    HIGH("Alta", 0.14f),
}

/** [shortSide] é o lado menor do vídeo (ex.: 1080 → 1080×1920 na vertical, 1920×1080 na horizontal). */
data class ExportSettings(val shortSide: Int, val fps: Int, val codec: Codec, val quality: Quality)

object ExportMath {
    val heights = listOf(
        360 to "360p", 480 to "480p", 720 to "720p HD",
        1080 to "1080p Full HD", 1440 to "1440p QHD", 2160 to "2160p 4K",
    )
    val fpsOptions = listOf(24, 25, 30, 50, 60, 90, 120)

    private fun even(x: Int) = ((x / 2) * 2).coerceAtLeast(2)

    fun outputSize(aspect: Float, shortSide: Int): Pair<Int, Int> {
        val w: Int
        val h: Int
        if (aspect < 1f) {
            w = shortSide
            h = (shortSide / aspect).roundToInt()
        } else {
            h = shortSide
            w = (shortSide * aspect).roundToInt()
        }
        return even(w) to even(h)
    }

    fun videoBitrate(w: Int, h: Int, fps: Int, codec: Codec, quality: Quality): Int =
        (w.toLong() * h * fps * quality.bpp * codec.bppFactor).toLong()
            .coerceIn(500_000L, 150_000_000L).toInt()

    fun estimateBytes(durationMs: Long, videoBps: Int, audioBps: Int = 128_000): Long =
        (videoBps + audioBps).toLong() * durationMs / 8000L
}
