package com.vortex.editor.data

import android.content.Context
import com.vortex.editor.model.Project
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/** Projetos salvos como JSON no armazenamento interno do app (nada sai do aparelho). */
class ProjectStore(context: Context) {
    private val dir = File(context.filesDir, "projects").apply { mkdirs() }
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun list(): List<Project> =
        dir.listFiles { f -> f.extension == "json" }.orEmpty()
            .mapNotNull { f -> runCatching { json.decodeFromString<Project>(f.readText()) }.getOrNull() }
            .sortedByDescending { it.updatedAt }

    fun load(id: String): Project? =
        runCatching { json.decodeFromString<Project>(File(dir, "$id.json").readText()) }.getOrNull()

    fun save(p: Project) {
        val tmp = File(dir, "${p.id}.tmp")
        tmp.writeText(json.encodeToString(p))
        tmp.renameTo(File(dir, "${p.id}.json"))
    }

    fun delete(id: String) {
        File(dir, "$id.json").delete()
    }
}
