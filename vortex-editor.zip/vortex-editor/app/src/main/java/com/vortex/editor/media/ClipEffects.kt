package com.vortex.editor.media

import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import com.vortex.editor.model.Clip
import com.vortex.editor.model.FxKind
import com.vortex.editor.model.MediaKind

fun previewItem(c: Clip): MediaItem {
    val b = MediaItem.Builder().setUri(c.uri).setMediaId(c.id)
    return if (c.kind == MediaKind.IMAGE) {
        b.setImageDurationMs(c.sourceSpanMs).build()
    } else {
        b.setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(c.trimStartMs)
                .setEndPositionMs(c.trimEndMs)
                .build()
        ).build()
    }
}

/**
 * Efeitos por clipe (cor, ajustes, efeitos GLSL). Usada na prévia ([export]=false)
 * e na exportação ([export]=true, que também ajusta o enquadramento e a velocidade).
 */
fun clipEffects(c: Clip?, export: Boolean, w: Int = 0, h: Int = 0): List<Effect> {
    val l = mutableListOf<Effect>()
    if (c == null) return l
    if (export) {
        l += Presentation.createForWidthAndHeight(
            w, h,
            if (c.fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT,
        )
        if (c.kind == MediaKind.VIDEO && c.speed != 1f) l += SpeedChangeEffect(c.speed)
    }
    if (c.brightness != 0f) l += Brightness(c.brightness)
    if (c.contrast != 0f) l += Contrast(c.contrast)
    if (c.saturation != 0f) l += HslAdjustment.Builder().adjustSaturation(c.saturation).build()
    if (c.temperature != 0f || c.vignette != 0f || c.fade != 0f || c.sharpen != 0f) {
        l += ShaderFx(FxKind.ADJUST, 1f, floatArrayOf(c.temperature, c.vignette, c.fade, c.sharpen))
    }
    c.fx.forEach { l += ShaderFx(it.kind, it.intensity) }
    return l
}
