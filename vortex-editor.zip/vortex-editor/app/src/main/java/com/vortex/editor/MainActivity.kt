package com.vortex.editor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.vortex.editor.ui.EditorScreen
import com.vortex.editor.ui.HomeScreen
import com.vortex.editor.ui.VortexTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        setContent {
            var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
            var openId by rememberSaveable { mutableStateOf<String?>(null) }
            VortexTheme(dark) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val id = openId
                    if (id == null) {
                        HomeScreen(
                            dark = dark,
                            onToggleTheme = { dark = !dark; prefs.edit().putBoolean("dark", dark).apply() },
                            onOpen = { openId = it },
                        )
                    } else {
                        EditorScreen(projectId = id, onBack = { openId = null })
                    }
                }
            }
        }
    }
}
