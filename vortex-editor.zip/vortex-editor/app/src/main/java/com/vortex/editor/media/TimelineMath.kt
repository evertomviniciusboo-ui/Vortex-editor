package com.vortex.editor.media

import com.vortex.editor.model.Project
import com.vortex.editor.model.TextAnim
import com.vortex.editor.model.TextItem
import com.vortex.editor.model.TransitionType
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Transformação do quadro final em um instante da linha do tempo.
 * Mesma matemática usada na PRÉVIA (Compose graphicsLayer) e na EXPORTAÇÃO (Media3 Matrix/Rgb).
 */
data class FrameXform(
    val scale: Float = 1f,
    val rotDeg: Float = 0f,
    val tx: Float = 0f,        // em coordenadas normalizadas (-1..1), + = direita
    val ty: Float = 0f,        // + = cima
    val flipX: Boolean = false,
    val flipY: Boolean = false,
    val dim: Float = 1f,       // 1 = normal, 0 = preto
    val white: Float = 0f,     // 0..1 = quanto de branco sobrepor
)

object TimelineMath {
    private fun ease(x: Float): Float {
        val t = x.coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    fun needsTransform(p: Project): Boolean = p.clips.any {
        it.zoom0 != 1f || it.zoom1 != 1f || it.rot0 != 0f || it.rot1 != 0f ||
            it.x0 != 0f || it.x1 != 0f || it.y0 != 0f || it.y1 != 0f ||
            it.flipH || it.flipV || it.opacity != 1f || it.transition != TransitionType.NONE
    }

    /** Metade da duração efetiva da transição no início do clipe [j] (j >= 1). */
    fun halfMs(p: Project, j: Int): Long {
        val c = p.clips[j]
        val prev = p.clips[j - 1]
        return minOf(c.transitionMs / 2, prev.durationMs / 2, c.durationMs / 2)
    }

    fun at(p: Project, tMs: Long): FrameXform {
        if (p.clips.isEmpty()) return FrameXform()
        var start = 0L
        var idx = 0
        for (i in p.clips.indices) {
            val d = p.clips[i].durationMs
            if (tMs < start + d || i == p.clips.lastIndex) {
                idx = i
                break
            }
            start += d
        }
        val c = p.clips[idx]
        val dur = maxOf(c.durationMs, 1L)
        val prog = ((tMs - start).toFloat() / dur).coerceIn(0f, 1f)
        val e = ease(prog)
        var xf = FrameXform(
            scale = lerp(c.zoom0, c.zoom1, e),
            rotDeg = lerp(c.rot0, c.rot1, e),
            tx = lerp(c.x0, c.x1, e),
            ty = lerp(c.y0, c.y1, e),
            flipX = c.flipH,
            flipY = c.flipV,
            dim = c.opacity,
        )
        for (j in idx..idx + 1) {
            if (j < 1 || j > p.clips.lastIndex) continue
            val tr = p.clips[j]
            if (tr.transition == TransitionType.NONE) continue
            val half = halfMs(p, j)
            if (half <= 0L) continue
            val boundary = if (j == idx) start else start + dur
            val u = (tMs - (boundary - half)).toFloat() / (2f * half)
            if (u in 0f..1f) xf = applyTransition(xf, tr.transition, u)
        }
        return xf
    }

    private fun slide(x: FrameXform, dx: Float, dy: Float, outHalf: Boolean, q: Float): FrameXform {
        val m = if (outHalf) 2f * q else -2f * (1f - q)
        return x.copy(tx = x.tx + dx * m, ty = x.ty + dy * m)
    }

    private fun applyTransition(x: FrameXform, type: TransitionType, u: Float): FrameXform {
        val k = 1f - abs(2f * u - 1f)      // 0 nas bordas, 1 no corte
        val ke = ease(k)
        val outHalf = u < 0.5f
        val q = if (outHalf) ease(2f * u) else ease(2f * (u - 0.5f))
        return when (type) {
            TransitionType.NONE -> x
            TransitionType.FADE_BLACK -> x.copy(dim = x.dim * (1f - ke))
            TransitionType.FADE_WHITE -> x.copy(white = maxOf(x.white, ke))
            TransitionType.LIGHT -> x.copy(white = maxOf(x.white, 0.85f * ke), scale = x.scale * (1f + 0.15f * ke))
            TransitionType.ZOOM_IN -> x.copy(scale = x.scale * (1f + 1.2f * ke), dim = x.dim * (1f - 0.5f * ke))
            TransitionType.ZOOM_OUT -> x.copy(scale = x.scale * (1f - 0.45f * ke), dim = x.dim * (1f - 0.7f * ke))
            TransitionType.SLIDE_LEFT -> slide(x, -1f, 0f, outHalf, q)
            TransitionType.SLIDE_RIGHT -> slide(x, 1f, 0f, outHalf, q)
            TransitionType.SLIDE_UP -> slide(x, 0f, 1f, outHalf, q)
            TransitionType.SLIDE_DOWN -> slide(x, 0f, -1f, outHalf, q)
            TransitionType.SPIN -> x.copy(
                rotDeg = x.rotDeg + (if (outHalf) 90f * q else -90f * (1f - q)),
                scale = x.scale * (1f - 0.25f * ke),
                dim = x.dim * (1f - ke),
            )
            TransitionType.SHAKE -> x.copy(
                tx = x.tx + sin(u * 60f) * 0.07f * ke,
                ty = x.ty + cos(u * 47f) * 0.05f * ke,
                scale = x.scale * (1f + 0.12f * ke),
            )
            TransitionType.IMPACT -> x.copy(
                scale = x.scale * (1f + 0.5f * ke * ke),
                white = maxOf(x.white, 0.7f * ke * ke * ke),
                tx = x.tx + sin(u * 80f) * 0.03f * ke,
            )
            TransitionType.PULSE -> x.copy(
                scale = x.scale * (1f + 0.25f * ke),
                white = maxOf(x.white, 0.25f * ke),
            )
            TransitionType.GLITCH -> x.copy(
                tx = x.tx + (if (sin(u * 90f) > 0f) 0.08f else -0.08f) * ke,
                dim = x.dim * (if (sin(u * 130f) > 0.3f) 1f else 0.45f),
            )
        }
    }
}

data class TextAnimState(val alpha: Float, val scale: Float, val dy: Float)

object TextAnimMath {
    /** [dy] = deslocamento para baixo como fração da altura do quadro. */
    fun state(t: TextItem, tMs: Long): TextAnimState {
        val inP = ((tMs - t.startMs) / 400f).coerceIn(0f, 1f)
        val outP = ((t.endMs - tMs) / 300f).coerceIn(0f, 1f)
        val a = minOf(inP, outP)
        return when (t.anim) {
            TextAnim.NONE -> TextAnimState(1f, 1f, 0f)
            TextAnim.FADE -> TextAnimState(a, 1f, 0f)
            TextAnim.POP -> TextAnimState(a, 0.6f + 0.4f * inP, 0f)
            TextAnim.SLIDE -> TextAnimState(a, 1f, 0.06f * (1f - inP))
        }
    }
}

/** Leitura e escrita de legendas SRT. */
object Srt {
    private val TIME = Regex("(\\d+):(\\d+):(\\d+)[,.](\\d+)")

    private fun toMs(s: String): Long? {
        val m = TIME.find(s) ?: return null
        val (h, mi, se, ms) = m.destructured
        val frac = ms.padEnd(3, '0').take(3)
        return (h.toLong() * 3600 + mi.toLong() * 60 + se.toLong()) * 1000 + frac.toLong()
    }

    fun parse(text: String): List<Triple<Long, Long, String>> {
        val out = mutableListOf<Triple<Long, Long, String>>()
        val blocks = text.replace("\r", "").replace("\uFEFF", "").trim().split(Regex("\n\\s*\n"))
        for (b in blocks) {
            val lines = b.lines().filter { it.isNotBlank() }
            val ti = lines.indexOfFirst { it.contains("-->") }
            if (ti < 0) continue
            val parts = lines[ti].split("-->")
            if (parts.size < 2) continue
            val s = toMs(parts[0].trim()) ?: continue
            val e = toMs(parts[1].trim().split(" ")[0]) ?: continue
            val txt = lines.drop(ti + 1).joinToString("\n")
            if (txt.isNotBlank()) out += Triple(s, e, txt)
        }
        return out
    }

    fun fmt(ms: Long): String {
        val t = ms.coerceAtLeast(0L)
        return "%02d:%02d:%02d,%03d".format(t / 3_600_000, (t / 60_000) % 60, (t / 1000) % 60, t % 1000)
    }

    fun write(items: List<TextItem>): String = buildString {
        items.sortedBy { it.startMs }.forEachIndexed { i, t ->
            append(i + 1).append('\n')
            append(fmt(t.startMs)).append(" --> ").append(fmt(t.endMs)).append('\n')
            append(t.text).append("\n\n")
        }
    }
}
