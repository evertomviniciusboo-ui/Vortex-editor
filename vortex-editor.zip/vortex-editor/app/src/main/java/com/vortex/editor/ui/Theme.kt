package com.vortex.editor.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun VortexTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF9D7BFF),
        onPrimary = Color.Black,
        background = Color(0xFF0E0E12),
        surface = Color(0xFF16161C),
        surfaceVariant = Color(0xFF23232B),
    ) else lightColorScheme(
        primary = Color(0xFF6C3CFF),
        background = Color(0xFFF6F5FA),
        surface = Color.White,
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
