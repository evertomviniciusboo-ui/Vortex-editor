package com.vortex.editor.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import com.vortex.editor.media.MediaUtils
import com.vortex.editor.model.MediaKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

fun fmt(ms: Long): String {
    val t = ms.coerceAtLeast(0L) / 100
    return "%02d:%02d.%d".format(t / 600, (t / 10) % 60, t % 10)
}

@Composable
fun Thumb(uri: String, kind: MediaKind, atMs: Long, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri, atMs / 1000) {
        value = withContext(Dispatchers.IO) { MediaUtils.thumbnail(ctx, Uri.parse(uri), kind, atMs) }
    }
    Box(modifier.background(Color(0xFF2A2A33))) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}
