package com.vortex.editor.media

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram
import com.vortex.editor.model.FxKind

/** Efeito de vídeo em GLSL (roda na GPU, igual na prévia e na exportação). */
class ShaderFx(
    val kind: FxKind,
    val intensity: Float,
    val params: FloatArray = FloatArray(4),
) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        FxProgram(kind, intensity, params, useHdr)
}

private class FxProgram(
    private val kind: FxKind,
    private val intensity: Float,
    private val params: FloatArray,
    useHdr: Boolean,
) : BaseGlShaderProgram(useHdr, 1) {

    private val program: GlProgram = createProgram(FxShaders.fragment(kind))
    private var w = 1
    private var h = 1

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        w = inputWidth
        h = inputHeight
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            program.use()
            program.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            program.setFloatUniform("uTime", (presentationTimeUs % 60_000_000L) / 1_000_000f)
            program.setFloatUniform("uIntensity", intensity)
            program.setFloatsUniform("uTexel", floatArrayOf(1f / w, 1f / h))
            program.setFloatsUniform("uP", params)
            program.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: Exception) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            program.delete()
        } catch (e: Exception) {
            throw VideoFrameProcessingException(e)
        }
    }

    private fun createProgram(fragment: String): GlProgram {
        try {
            val p = GlProgram(FxShaders.VERTEX, fragment)
            p.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE,
            )
            val id = GlUtil.create4x4IdentityMatrix()
            p.setFloatsUniform("uTransformationMatrix", id)
            p.setFloatsUniform("uTexTransformationMatrix", id)
            return p
        } catch (e: Exception) {
            throw VideoFrameProcessingException(e)
        }
    }
}

object FxShaders {
    const val VERTEX = """
attribute vec4 aFramePosition;
uniform mat4 uTransformationMatrix;
uniform mat4 uTexTransformationMatrix;
varying vec2 vTexSamplingCoord;
void main() {
  gl_Position = uTransformationMatrix * aFramePosition;
  vec4 texturePosition = vec4(aFramePosition.x * 0.5 + 0.5, aFramePosition.y * 0.5 + 0.5, 0.0, 1.0);
  vTexSamplingCoord = (uTexTransformationMatrix * texturePosition).xy;
}
"""

    private const val HEADER = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform sampler2D uTexSampler;
uniform float uTime;
uniform float uIntensity;
uniform vec2 uTexel;
uniform vec4 uP;
varying vec2 vTexSamplingCoord;
float rand(vec2 co) { return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453); }
vec4 tex(vec2 uv) { return texture2D(uTexSampler, clamp(uv, 0.0, 1.0)); }
"""

    private const val FOOTER = """
void main() {
  vec4 c = fx(vTexSamplingCoord);
  c.rgb += (uTime + uIntensity + uTexel.x + uTexel.y + uP.x + uP.y + uP.z + uP.w) * 1e-9;
  gl_FragColor = vec4(clamp(c.rgb, 0.0, 1.0), 1.0);
}
"""

    fun fragment(kind: FxKind): String = HEADER + body(kind) + FOOTER

    private fun body(kind: FxKind): String = when (kind) {
        FxKind.GLITCH -> """
vec4 fx(vec2 uv) {
  float t = floor(uTime * 12.0);
  float band = floor(uv.y * 14.0);
  float r = rand(vec2(band, t));
  float on = step(1.0 - 0.35 * uIntensity, r);
  float shift = (rand(vec2(t, band)) - 0.5) * 0.15 * uIntensity * on;
  vec2 u = vec2(uv.x + shift, uv.y);
  float split = 0.012 * uIntensity * on;
  return vec4(tex(u + vec2(split, 0.0)).r, tex(u).g, tex(u - vec2(split, 0.0)).b, 1.0);
}
"""
        FxKind.CHROMATIC -> """
vec4 fx(vec2 uv) {
  vec2 d = (uv - 0.5) * 0.04 * uIntensity;
  return vec4(tex(uv + d).r, tex(uv).g, tex(uv - d).b, 1.0);
}
"""
        FxKind.VHS -> """
vec4 fx(vec2 uv) {
  float row = floor(uv.y / (uTexel.y * 3.0));
  float wob = (rand(vec2(row, floor(uTime * 15.0))) - 0.5) * 0.006 * uIntensity + sin(uv.y * 30.0 + uTime * 6.0) * 0.0015 * uIntensity;
  vec2 u = vec2(uv.x + wob, uv.y);
  float o = 0.005 * uIntensity;
  vec3 c = vec3(tex(u + vec2(o, 0.0)).r, tex(u).g, tex(u - vec2(o, 0.0)).b);
  float scan = 1.0 - 0.18 * uIntensity * (0.5 + 0.5 * sin(uv.y / uTexel.y * 2.0));
  c += (rand(uv + fract(uTime)) - 0.5) * 0.12 * uIntensity;
  c = mix(c, vec3(dot(c, vec3(0.3, 0.59, 0.11))), 0.15 * uIntensity);
  return vec4(c * scan, 1.0);
}
"""
        FxKind.GRAIN -> """
vec4 fx(vec2 uv) {
  vec4 c = tex(uv);
  float n = (rand(uv + fract(uTime)) - 0.5) * 0.35 * uIntensity;
  return vec4(c.rgb + n, 1.0);
}
"""
        FxKind.BLUR -> """
vec4 fx(vec2 uv) {
  vec2 s = uTexel * (1.0 + 10.0 * uIntensity);
  vec4 acc = vec4(0.0);
  float wsum = 0.0;
  for (int i = -3; i <= 3; i++) {
    for (int j = -3; j <= 3; j++) {
      float w = exp(-float(i * i + j * j) / 6.0);
      acc += tex(uv + vec2(float(i), float(j)) * s) * w;
      wsum += w;
    }
  }
  return acc / wsum;
}
"""
        FxKind.MOTION_BLUR -> """
vec4 fx(vec2 uv) {
  vec2 d = vec2(0.04 * uIntensity, 0.0);
  vec4 acc = vec4(0.0);
  for (int k = 0; k < 9; k++) {
    acc += tex(uv + d * (float(k) / 8.0 - 0.5));
  }
  return acc / 9.0;
}
"""
        FxKind.ZOOM_BLUR -> """
vec4 fx(vec2 uv) {
  vec2 d = (uv - 0.5) * 0.12 * uIntensity;
  vec4 acc = vec4(0.0);
  for (int k = 0; k < 10; k++) {
    acc += tex(uv - d * (float(k) / 9.0));
  }
  return acc / 10.0;
}
"""
        FxKind.BLOOM -> """
vec4 fx(vec2 uv) {
  vec4 c = tex(uv);
  vec3 b = vec3(0.0);
  for (int i = -2; i <= 2; i++) {
    for (int j = -2; j <= 2; j++) {
      vec3 s = tex(uv + vec2(float(i), float(j)) * uTexel * 6.0).rgb;
      b += max(s - 0.6, 0.0);
    }
  }
  b /= 25.0;
  return vec4(c.rgb + b * 3.5 * uIntensity, 1.0);
}
"""
        FxKind.PIXELATE -> """
vec4 fx(vec2 uv) {
  float size = 2.0 + 40.0 * uIntensity;
  vec2 cell = uTexel * size;
  vec2 u = (floor(uv / cell) + 0.5) * cell;
  return tex(u);
}
"""
        FxKind.MIRROR -> """
vec4 fx(vec2 uv) {
  vec2 u = uv;
  if (u.x > 0.5) { u.x = 1.0 - u.x; }
  return tex(u);
}
"""
        FxKind.WAVE -> """
vec4 fx(vec2 uv) {
  vec2 u = uv + vec2(sin(uv.y * 20.0 + uTime * 4.0) * 0.015 * uIntensity, cos(uv.x * 20.0 + uTime * 4.0) * 0.01 * uIntensity);
  return tex(u);
}
"""
        FxKind.SHAKE_CAM -> """
vec4 fx(vec2 uv) {
  vec2 j = vec2(sin(uTime * 47.0), cos(uTime * 53.0)) * 0.012 * uIntensity;
  vec2 u = (uv - 0.5) / (1.0 + 0.05 * uIntensity) + 0.5 + j;
  return tex(u);
}
"""
        FxKind.PULSE_ZOOM -> """
vec4 fx(vec2 uv) {
  float z = 1.0 + 0.12 * uIntensity * (0.5 + 0.5 * sin(uTime * 12.566));
  return tex((uv - 0.5) / z + 0.5);
}
"""
        FxKind.LENS_FLARE -> """
vec4 fx(vec2 uv) {
  vec4 c = tex(uv);
  float asp = uTexel.y / uTexel.x;
  vec2 p = vec2(0.5 + 0.3 * sin(uTime * 0.7), 0.3 + 0.1 * cos(uTime * 0.5));
  float d = length((uv - p) * vec2(asp, 1.0));
  float glow = exp(-d * 6.0) * 0.8 + exp(-d * 30.0);
  float d2 = length((uv - (1.0 - p)) * vec2(asp, 1.0));
  float ring = exp(-pow(d2 - 0.12, 2.0) * 800.0) * 0.25;
  return vec4(c.rgb + vec3(1.0, 0.85, 0.6) * (glow + ring) * 0.6 * uIntensity, 1.0);
}
"""
        FxKind.LIGHT_LEAK -> """
vec4 fx(vec2 uv) {
  vec4 c = tex(uv);
  float g = smoothstep(0.0, 1.0, 1.0 - uv.x) * 0.5 * (0.6 + 0.4 * sin(uTime * 1.5));
  vec3 leak = mix(vec3(1.0, 0.35, 0.1), vec3(1.0, 0.8, 0.2), uv.y);
  return vec4(c.rgb + leak * g * uIntensity, 1.0);
}
"""
        FxKind.SPARKLES -> """
vec4 fx(vec2 uv) {
  float asp = uTexel.y / uTexel.x;
  vec2 g = uv * vec2(24.0 * asp, 24.0);
  vec2 id = floor(g);
  vec2 f = fract(g) - 0.5;
  float r = rand(id);
  float tw = 0.5 + 0.5 * sin(uTime * (2.0 + r * 4.0) + r * 20.0);
  vec2 o = vec2(rand(id + 1.7), rand(id + 3.1)) - 0.5;
  float d = length(f - o * 0.6);
  float s = step(0.85, r) * tw * (1.0 - smoothstep(0.0, 0.12, d));
  return vec4(tex(uv).rgb + vec3(1.0, 0.95, 0.8) * s * uIntensity * 1.5, 1.0);
}
"""
        FxKind.RETRO -> """
vec4 fx(vec2 uv) {
  vec4 c = tex(uv);
  vec3 v = c.rgb;
  v = mix(v, vec3(dot(v, vec3(0.3, 0.59, 0.11))), 0.3);
  v *= vec3(1.1, 1.0, 0.85);
  v = v * 0.85 + 0.08;
  float vig = 1.0 - smoothstep(0.3, 0.9, length(uv - 0.5));
  v *= mix(1.0, vig, 0.6);
  v += (rand(uv + fract(uTime)) - 0.5) * 0.08;
  return vec4(mix(c.rgb, v, uIntensity), 1.0);
}
"""
        FxKind.ANIME -> """
vec4 fx(vec2 uv) {
  vec3 base = tex(uv).rgb;
  float l = dot(base, vec3(0.3, 0.59, 0.11));
  vec3 c = mix(vec3(l), base, 1.4);
  c = floor(c * 5.0 + 0.5) / 5.0;
  float e = abs(dot(tex(uv + vec2(uTexel.x, 0.0)).rgb - tex(uv - vec2(uTexel.x, 0.0)).rgb, vec3(0.33)))
          + abs(dot(tex(uv + vec2(0.0, uTexel.y)).rgb - tex(uv - vec2(0.0, uTexel.y)).rgb, vec3(0.33)));
  c *= 1.0 - smoothstep(0.1, 0.4, e);
  return vec4(mix(base, c, uIntensity), 1.0);
}
"""
        FxKind.MASK_CIRCLE -> """
vec4 fx(vec2 uv) {
  float asp = uTexel.y / uTexel.x;
  float r = mix(0.9, 0.2, uIntensity);
  float m = 1.0 - smoothstep(r - 0.02, r, length((uv - 0.5) * vec2(asp, 1.0)));
  return vec4(tex(uv).rgb * m, 1.0);
}
"""
        FxKind.CINEMA_BARS -> """
vec4 fx(vec2 uv) {
  float bar = 0.04 + 0.16 * uIntensity;
  float m = step(bar, uv.y) * step(uv.y, 1.0 - bar);
  return vec4(tex(uv).rgb * m, 1.0);
}
"""
        FxKind.BW -> """
vec4 fx(vec2 uv) {
  vec3 c = tex(uv).rgb;
  float l = dot(c, vec3(0.3, 0.59, 0.11));
  l = (l - 0.5) * 1.1 + 0.5;
  return vec4(mix(c, vec3(l), uIntensity), 1.0);
}
"""
        FxKind.SEPIA -> """
vec4 fx(vec2 uv) {
  vec3 c = tex(uv).rgb;
  vec3 s = vec3(dot(c, vec3(0.393, 0.769, 0.189)), dot(c, vec3(0.349, 0.686, 0.168)), dot(c, vec3(0.272, 0.534, 0.131)));
  return vec4(mix(c, s, uIntensity), 1.0);
}
"""
        FxKind.CINEMATIC -> """
vec4 fx(vec2 uv) {
  vec3 c = tex(uv).rgb;
  float l = dot(c, vec3(0.3, 0.59, 0.11));
  vec3 g = c + mix(vec3(-0.04, 0.02, 0.07), vec3(0.09, 0.03, -0.05), l);
  g = (g - 0.5) * 1.12 + 0.5;
  return vec4(mix(c, g, uIntensity), 1.0);
}
"""
        FxKind.WARM -> """
vec4 fx(vec2 uv) {
  vec3 c = tex(uv).rgb;
  vec3 g = c * vec3(1.08, 1.0, 0.9) + 0.02;
  return vec4(mix(c, g, uIntensity), 1.0);
}
"""
        FxKind.COLD -> """
vec4 fx(vec2 uv) {
  vec3 c = tex(uv).rgb;
  vec3 g = c * vec3(0.9, 1.0, 1.1);
  return vec4(mix(c, g, uIntensity), 1.0);
}
"""
        FxKind.DRAMATIC -> """
vec4 fx(vec2 uv) {
  vec3 c = tex(uv).rgb;
  vec3 g = (c - 0.5) * 1.35 + 0.5;
  float l = dot(g, vec3(0.3, 0.59, 0.11));
  g = mix(vec3(l), g, 0.8);
  float v = 1.0 - smoothstep(0.35, 1.0, length(uv - 0.5));
  g *= mix(1.0, v, 0.5);
  return vec4(mix(c, g, uIntensity), 1.0);
}
"""
        FxKind.FADED -> """
vec4 fx(vec2 uv) {
  vec3 c = tex(uv).rgb;
  vec3 g = mix(c, vec3(dot(c, vec3(0.3, 0.59, 0.11))), 0.2) * 0.85 + 0.1;
  return vec4(mix(c, g, uIntensity), 1.0);
}
"""
        FxKind.VIVID -> """
vec4 fx(vec2 uv) {
  vec3 c = tex(uv).rgb;
  float l = dot(c, vec3(0.3, 0.59, 0.11));
  vec3 g = mix(vec3(l), c, 1.5);
  g = (g - 0.5) * 1.1 + 0.5;
  return vec4(mix(c, g, uIntensity), 1.0);
}
"""
        FxKind.NEGATIVE -> """
vec4 fx(vec2 uv) {
  vec3 c = tex(uv).rgb;
  return vec4(mix(c, 1.0 - c, uIntensity), 1.0);
}
"""
        FxKind.ADJUST -> """
vec4 fx(vec2 uv) {
  vec3 c = tex(uv).rgb;
  vec3 b = (tex(uv + vec2(uTexel.x, 0.0)).rgb + tex(uv - vec2(uTexel.x, 0.0)).rgb
          + tex(uv + vec2(0.0, uTexel.y)).rgb + tex(uv - vec2(0.0, uTexel.y)).rgb) * 0.25;
  c += (c - b) * uP.w * 2.5;
  c.r += uP.x * 0.12;
  c.b -= uP.x * 0.12;
  c = c * (1.0 - 0.25 * uP.z) + 0.12 * uP.z;
  float asp = uTexel.y / uTexel.x;
  float v = 1.0 - smoothstep(0.3, 0.95, length((uv - 0.5) * vec2(asp, 1.0)));
  c *= mix(1.0, v, uP.y);
  return vec4(c, 1.0);
}
"""
    }
}
