package com.vortex.editor.media

import android.media.MediaCodecInfo
import android.media.MediaCodecList

/**
 * Consulta REAL dos codificadores do aparelho. Isto só diz o que o codec anuncia;
 * não garante velocidade de renderização nem que a fonte/decodificação acompanhe.
 */
object DeviceCaps {
    private fun encoders(mime: String): List<MediaCodecInfo> =
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { info ->
            info.isEncoder && info.supportedTypes.any { it.equals(mime, ignoreCase = true) }
        }

    fun hasEncoder(codec: Codec): Boolean = encoders(codec.mime).isNotEmpty()

    fun isSupported(codec: Codec, w: Int, h: Int, fps: Int): Boolean =
        encoders(codec.mime).any { info ->
            runCatching {
                info.getCapabilitiesForType(codec.mime).videoCapabilities
                    .areSizeAndRateSupported(w, h, fps.toDouble())
            }.getOrDefault(false)
        }

    /** Melhor configuração "segura": maior resolução suportada a 30 fps e, nela, até 60 fps. */
    fun bestSafe(codec: Codec, aspect: Float): Pair<Int, Int>? {
        val side = ExportMath.heights.map { it.first }.sortedDescending().firstOrNull { s ->
            val (w, h) = ExportMath.outputSize(aspect, s)
            isSupported(codec, w, h, 30)
        } ?: return null
        val (w, h) = ExportMath.outputSize(aspect, side)
        val fps = ExportMath.fpsOptions.filter { it <= 60 }.sortedDescending()
            .firstOrNull { isSupported(codec, w, h, it) } ?: 30
        return side to fps
    }
}
