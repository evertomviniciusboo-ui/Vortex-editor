package com.vortex.editor.media

import android.graphics.Matrix
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.RgbMatrix
import com.vortex.editor.model.Project

/** Keyframes (zoom/rotação/posição/espelho) e transições, em função do tempo global da exportação. */
class TimelineMatrix(private val p: Project, private val w: Int, private val h: Int) : MatrixTransformation {
    override fun getMatrix(presentationTimeUs: Long): Matrix {
        val xf = TimelineMath.at(p, presentationTimeUs / 1000)
        val m = Matrix()
        m.postScale(
            xf.scale * (if (xf.flipX) -1f else 1f),
            xf.scale * (if (xf.flipY) -1f else 1f),
        )
        if (xf.rotDeg != 0f) {
            val a = w.toFloat() / h.toFloat()
            m.postScale(a, 1f)
            m.postRotate(-xf.rotDeg)
            m.postScale(1f / a, 1f)
        }
        m.postTranslate(xf.tx, xf.ty)
        return m
    }
}

/** Opacidade, fade para preto e flash branco das transições. */
class TimelineRgb(private val p: Project) : RgbMatrix {
    override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray {
        val xf = TimelineMath.at(p, presentationTimeUs / 1000)
        val wv = xf.white.coerceIn(0f, 1f)
        val s = xf.dim.coerceIn(0f, 1f) * (1f - wv)
        return floatArrayOf(
            s, 0f, 0f, 0f,
            0f, s, 0f, 0f,
            0f, 0f, s, 0f,
            wv, wv, wv, 1f,
        )
    }
}
