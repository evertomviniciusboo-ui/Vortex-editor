package com.vortex.editor.model

import kotlinx.serialization.Serializable

@Serializable
enum class MediaKind { VIDEO, IMAGE }

@Serializable
enum class TransitionType(val label: String) {
    NONE("Nenhuma"),
    FADE_BLACK("Fade preto"),
    FADE_WHITE("Flash branco"),
    LIGHT("Luz"),
    ZOOM_IN("Zoom in"),
    ZOOM_OUT("Zoom out"),
    SLIDE_LEFT("Deslizar ←"),
    SLIDE_RIGHT("Deslizar →"),
    SLIDE_UP("Deslizar ↑"),
    SLIDE_DOWN("Deslizar ↓"),
    SPIN("Giro"),
    SHAKE("Shake"),
    IMPACT("Impacto"),
    PULSE("Pulso"),
    GLITCH("Glitch"),
}

enum class FxCategory { EFFECT, FILTER, HIDDEN }

@Serializable
enum class FxKind(val label: String, val category: FxCategory) {
    GLITCH("Glitch digital", FxCategory.EFFECT),
    CHROMATIC("Aberração cromática", FxCategory.EFFECT),
    VHS("VHS", FxCategory.EFFECT),
    GRAIN("Granulação", FxCategory.EFFECT),
    BLUR("Desfoque", FxCategory.EFFECT),
    MOTION_BLUR("Motion blur", FxCategory.EFFECT),
    ZOOM_BLUR("Zoom blur", FxCategory.EFFECT),
    BLOOM("Bloom / brilho", FxCategory.EFFECT),
    PIXELATE("Pixelização", FxCategory.EFFECT),
    MIRROR("Espelho", FxCategory.EFFECT),
    WAVE("Ondas", FxCategory.EFFECT),
    SHAKE_CAM("Tremor de câmera", FxCategory.EFFECT),
    PULSE_ZOOM("Zoom dinâmico", FxCategory.EFFECT),
    LENS_FLARE("Lens flare", FxCategory.EFFECT),
    LIGHT_LEAK("Vazamento de luz", FxCategory.EFFECT),
    SPARKLES("Partículas", FxCategory.EFFECT),
    RETRO("Retrô", FxCategory.EFFECT),
    ANIME("Anime", FxCategory.EFFECT),
    MASK_CIRCLE("Máscara círculo", FxCategory.EFFECT),
    CINEMA_BARS("Barras cinema", FxCategory.EFFECT),

    BW("Preto e branco", FxCategory.FILTER),
    SEPIA("Sépia", FxCategory.FILTER),
    CINEMATIC("Cinematográfico", FxCategory.FILTER),
    WARM("Quente", FxCategory.FILTER),
    COLD("Frio", FxCategory.FILTER),
    DRAMATIC("Dramático", FxCategory.FILTER),
    FADED("Desbotado", FxCategory.FILTER),
    VIVID("Vívido", FxCategory.FILTER),
    NEGATIVE("Negativo", FxCategory.FILTER),

    ADJUST("Ajustes", FxCategory.HIDDEN),
}

@Serializable
enum class TextAnim(val label: String) {
    NONE("Nenhuma"), FADE("Fade"), POP("Pop"), SLIDE("Subir")
}

@Serializable
data class FxItem(val id: String, val kind: FxKind, val intensity: Float = 0.6f)

/** Um clipe na trilha principal. Edição não destrutiva: o arquivo original nunca é alterado. */
@Serializable
data class Clip(
    val id: String,
    val uri: String,
    val kind: MediaKind,
    val sourceDurationMs: Long,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = sourceDurationMs,
    val speed: Float = 1f,
    val volume: Float = 1f,
    val brightness: Float = 0f,   // -1..1
    val contrast: Float = 0f,     // -1..1
    val saturation: Float = 0f,   // -100..100
    // --- v0.2 ---
    val temperature: Float = 0f,  // -1..1
    val vignette: Float = 0f,     // 0..1
    val fade: Float = 0f,         // 0..1 (matte)
    val sharpen: Float = 0f,      // 0..1
    val fx: List<FxItem> = emptyList(),
    val transition: TransitionType = TransitionType.NONE, // transição ENTRE o clipe anterior e este
    val transitionMs: Long = 600L,
    // Animação por 2 keyframes (início → fim do clipe)
    val zoom0: Float = 1f, val zoom1: Float = 1f,
    val rot0: Float = 0f, val rot1: Float = 0f,
    val x0: Float = 0f, val x1: Float = 0f,
    val y0: Float = 0f, val y1: Float = 0f,
    val opacity: Float = 1f,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    val fill: Boolean = false,    // preencher o quadro (corta) em vez de ajustar (barras)
) {
    val sourceSpanMs: Long get() = trimEndMs - trimStartMs
    val durationMs: Long
        get() = if (kind == MediaKind.IMAGE) sourceSpanMs else (sourceSpanMs / speed).toLong()
}

@Serializable
data class TextItem(
    val id: String,
    val text: String = "Texto",
    val startMs: Long,
    val endMs: Long,
    val xPct: Float = 50f,     // 0..100 (esquerda → direita)
    val yPct: Float = 80f,     // 0..100 (topo → base)
    val sizePct: Float = 7f,   // altura do texto em % da largura do vídeo
    val color: Int = -1,       // ARGB (branco)
    val bold: Boolean = true,
    // --- v0.2 ---
    val bgColor: Int = 0,      // 0 = sem fundo
    val anim: TextAnim = TextAnim.NONE,
    val font: String = "sans", // sans | serif | mono | cursive | condensed
)

@Serializable
data class AudioItem(
    val id: String,
    val uri: String,
    val name: String,
    val durationMs: Long,
    val volume: Float = 1f,
)

@Serializable
data class Project(
    val id: String,
    val name: String,
    val aspect: String = "9:16",
    val clips: List<Clip> = emptyList(),
    val texts: List<TextItem> = emptyList(),
    val audios: List<AudioItem> = emptyList(),
    val updatedAt: Long = 0L,
) {
    val durationMs: Long get() = clips.sumOf { it.durationMs }

    val aspectRatio: Float
        get() = when (aspect) {
            "16:9" -> 16f / 9f
            "1:1" -> 1f
            "4:5" -> 4f / 5f
            "4:3" -> 4f / 3f
            "21:9" -> 21f / 9f
            else -> 9f / 16f
        }

    fun startOf(index: Int): Long = clips.take(index).sumOf { it.durationMs }

    /** Tempo global da linha do tempo a partir da posição (em tempo de mídia) dentro do clipe [index]. */
    fun globalMs(index: Int, itemPosMs: Long): Long {
        val c = clips.getOrNull(index) ?: return durationMs
        val local = if (c.kind == MediaKind.IMAGE) itemPosMs else (itemPosMs / c.speed).toLong()
        return startOf(index) + local
    }

    /** Converte tempo global em (índice do clipe, posição em tempo de mídia dentro do clipe). */
    fun locate(globalMs: Long): Pair<Int, Long>? {
        var acc = 0L
        clips.forEachIndexed { i, c ->
            if (globalMs < acc + c.durationMs || i == clips.lastIndex) {
                val local = (globalMs - acc).coerceIn(0L, c.durationMs)
                val media = if (c.kind == MediaKind.IMAGE) local else (local * c.speed).toLong()
                return i to media.coerceAtMost(c.sourceSpanMs)
            }
            acc += c.durationMs
        }
        return null
    }
}
