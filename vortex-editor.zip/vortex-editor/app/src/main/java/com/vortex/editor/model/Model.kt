package com.vortex.editor.model

import kotlinx.serialization.Serializable

@Serializable
enum class MediaKind { VIDEO, IMAGE }

/** Um clipe na trilha principal. Edição não destrutiva: o arquivo original nunca é alterado. */
@Serializable
data class Clip(
    val id: String,
    val uri: String,
    val kind: MediaKind,
    val sourceDurationMs: Long,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = sourceDurationMs,
    val speed: Float = 1f,
    val volume: Float = 1f,
    val brightness: Float = 0f,   // -1..1
    val contrast: Float = 0f,     // -1..1
    val saturation: Float = 0f,   // -100..100
) {
    val sourceSpanMs: Long get() = trimEndMs - trimStartMs
    val durationMs: Long
        get() = if (kind == MediaKind.IMAGE) sourceSpanMs else (sourceSpanMs / speed).toLong()
}

@Serializable
data class TextItem(
    val id: String,
    val text: String = "Texto",
    val startMs: Long,
    val endMs: Long,
    val xPct: Float = 50f,     // 0..100 (esquerda → direita)
    val yPct: Float = 80f,     // 0..100 (topo → base)
    val sizePct: Float = 7f,   // altura do texto em % da largura do vídeo
    val color: Int = -1,       // ARGB (branco)
    val bold: Boolean = true,
)

@Serializable
data class AudioItem(
    val id: String,
    val uri: String,
    val name: String,
    val durationMs: Long,
    val volume: Float = 1f,
)

@Serializable
data class Project(
    val id: String,
    val name: String,
    val aspect: String = "9:16",
    val clips: List<Clip> = emptyList(),
    val texts: List<TextItem> = emptyList(),
    val audios: List<AudioItem> = emptyList(),
    val updatedAt: Long = 0L,
) {
    val durationMs: Long get() = clips.sumOf { it.durationMs }

    val aspectRatio: Float
        get() = when (aspect) {
            "16:9" -> 16f / 9f
            "1:1" -> 1f
            "4:5" -> 4f / 5f
            else -> 9f / 16f
        }

    fun startOf(index: Int): Long = clips.take(index).sumOf { it.durationMs }

    /** Tempo global da linha do tempo a partir da posição (em tempo de mídia) dentro do clipe [index]. */
    fun globalMs(index: Int, itemPosMs: Long): Long {
        val c = clips.getOrNull(index) ?: return durationMs
        val local = if (c.kind == MediaKind.IMAGE) itemPosMs else (itemPosMs / c.speed).toLong()
        return startOf(index) + local
    }

    /** Converte tempo global em (índice do clipe, posição em tempo de mídia dentro do clipe). */
    fun locate(globalMs: Long): Pair<Int, Long>? {
        var acc = 0L
        clips.forEachIndexed { i, c ->
            if (globalMs < acc + c.durationMs || i == clips.lastIndex) {
                val local = (globalMs - acc).coerceIn(0L, c.durationMs)
                val media = if (c.kind == MediaKind.IMAGE) local else (local * c.speed).toLong()
                return i to media.coerceAtMost(c.sourceSpanMs)
            }
            acc += c.durationMs
        }
        return null
    }
}
