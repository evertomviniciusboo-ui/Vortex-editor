package com.vortex.editor.media

import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import com.vortex.editor.model.Clip
import com.vortex.editor.model.MediaKind

fun previewItem(c: Clip): MediaItem {
    val b = MediaItem.Builder().setUri(c.uri).setMediaId(c.id)
    return if (c.kind == MediaKind.IMAGE) {
        b.setImageDurationMs(c.sourceSpanMs).build()
    } else {
        b.setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(c.trimStartMs)
                .setEndPositionMs(c.trimEndMs)
                .build()
        ).build()
    }
}

fun previewEffects(c: Clip?): List<Effect> {
    val l = mutableListOf<Effect>()
    if (c == null) return l
    if (c.brightness != 0f) l += Brightness(c.brightness)
    if (c.contrast != 0f) l += Contrast(c.contrast)
    if (c.saturation != 0f) l += HslAdjustment.Builder().adjustSaturation(c.saturation).build()
    return l
}
