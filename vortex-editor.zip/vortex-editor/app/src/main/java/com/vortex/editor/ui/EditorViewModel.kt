package com.vortex.editor.ui

import android.app.Application
import android.content.ContentValues
import android.net.Uri
import android.os.SystemClock
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.vortex.editor.data.ProjectStore
import com.vortex.editor.media.CompositionBuilder
import com.vortex.editor.media.ExportMath
import com.vortex.editor.media.ExportSettings
import com.vortex.editor.media.MediaUtils
import com.vortex.editor.model.AudioItem
import com.vortex.editor.model.Clip
import com.vortex.editor.model.MediaKind
import com.vortex.editor.model.Project
import com.vortex.editor.model.TextItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val progress: Float) : ExportState
    data class Done(val uri: Uri) : ExportState
    data class Failed(val message: String) : ExportState
}

class EditorViewModel(app: Application, projectId: String) : AndroidViewModel(app) {
    private val store = ProjectStore(app)
    private val _project = MutableStateFlow(store.load(projectId) ?: Project(projectId, "Projeto"))
    val project: StateFlow<Project> = _project.asStateFlow()

    var selectedClipId by mutableStateOf<String?>(null)
    var selectedTextId by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    var copiedAdjust by mutableStateOf<Triple<Float, Float, Float>?>(null)
    var exportState by mutableStateOf<ExportState>(ExportState.Idle)
        private set

    private val undoStack = ArrayDeque<Project>()
    private val redoStack = ArrayDeque<Project>()
    private var lastKey: String? = null
    private var lastAt = 0L
    private var transformer: Transformer? = null
    private var progressJob: Job? = null

    init {
        // Salvamento automático (debounce) — projetos sobrevivem a fechamentos inesperados.
        viewModelScope.launch {
            _project.drop(1).debounce(500).collect { p -> withContext(Dispatchers.IO) { store.save(p) } }
        }
    }

    private fun newId() = UUID.randomUUID().toString()

    private fun refreshFlags() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    /** [key] agrupa edições contínuas (ex.: arrastar um slider) em um único passo de desfazer. */
    fun edit(key: String? = null, f: (Project) -> Project) {
        val old = _project.value
        val changed = f(old)
        if (changed == old) return
        val now = SystemClock.elapsedRealtime()
        if (key == null || key != lastKey || now - lastAt > 1200) {
            undoStack.addLast(old)
            if (undoStack.size > 100) undoStack.removeFirst()
            redoStack.clear()
        }
        lastKey = key
        lastAt = now
        _project.value = changed.copy(updatedAt = System.currentTimeMillis())
        refreshFlags()
    }

    fun undo() {
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(_project.value)
        _project.value = prev
        lastKey = null
        refreshFlags()
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(_project.value)
        _project.value = next
        lastKey = null
        refreshFlags()
    }

    fun rename(name: String) = edit("rename") { it.copy(name = name) }
    fun setAspect(a: String) = edit { it.copy(aspect = a) }

    // ---------- Mídia ----------
    fun addMedia(uris: List<Uri>) {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            var failed = 0
            val clips = withContext(Dispatchers.IO) {
                uris.mapNotNull { u ->
                    val info = MediaUtils.probe(ctx, u)
                    when {
                        info == null -> { failed++; null }
                        info.kind == MediaKind.IMAGE ->
                            Clip(newId(), u.toString(), MediaKind.IMAGE, 15_000L, 0L, 3_000L)
                        else -> Clip(newId(), u.toString(), MediaKind.VIDEO, info.durationMs)
                    }
                }
            }
            if (clips.isNotEmpty()) edit { it.copy(clips = it.clips + clips) }
            if (failed > 0) message = "$failed arquivo(s) não puderam ser lidos (formato incompatível?)."
        }
    }

    fun addAudio(uri: Uri) {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val item = withContext(Dispatchers.IO) {
                val info = MediaUtils.probe(ctx, uri)
                if (info == null || info.kind != MediaKind.VIDEO) null
                else AudioItem(newId(), uri.toString(), MediaUtils.displayName(ctx, uri), info.durationMs)
            }
            if (item == null) message = "Não foi possível ler esse áudio."
            else edit { it.copy(audios = it.audios + item) }
        }
    }

    // ---------- Clipes ----------
    fun updateClip(id: String, key: String? = null, f: (Clip) -> Clip) =
        edit(key) { p -> p.copy(clips = p.clips.map { if (it.id == id) f(it) else it }) }

    fun deleteClip(id: String) {
        edit { p -> p.copy(clips = p.clips.filter { it.id != id }) }
        if (selectedClipId == id) selectedClipId = null
    }

    fun duplicateClip(id: String) = edit { p ->
        val i = p.clips.indexOfFirst { it.id == id }
        if (i < 0) p else p.copy(clips = p.clips.toMutableList().also { it.add(i + 1, p.clips[i].copy(id = newId())) })
    }

    fun moveClip(id: String, delta: Int) = edit { p ->
        val i = p.clips.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j !in p.clips.indices) p
        else p.copy(clips = p.clips.toMutableList().also { val c = it.removeAt(i); it.add(j, c) })
    }

    /** [posMs] é a posição em tempo de mídia relativa ao início do trecho do clipe. */
    fun splitClip(id: String, posMs: Long) {
        val p = _project.value
        val i = p.clips.indexOfFirst { it.id == id }
        if (i < 0) return
        val c = p.clips[i]
        val sp = c.trimStartMs + posMs
        if (sp - c.trimStartMs < 200 || c.trimEndMs - sp < 200) {
            message = "Posicione o cursor mais ao meio do clipe para dividir."
            return
        }
        val a = c.copy(trimEndMs = sp)
        val b = c.copy(id = newId(), trimStartMs = sp)
        edit { it.copy(clips = it.clips.toMutableList().also { l -> l[i] = a; l.add(i + 1, b) }) }
    }

    fun copyAdjust(c: Clip) {
        copiedAdjust = Triple(c.brightness, c.contrast, c.saturation)
        message = "Ajustes de cor copiados."
    }

    fun pasteAdjust(id: String) {
        copiedAdjust?.let { (b, c, s) -> updateClip(id) { it.copy(brightness = b, contrast = c, saturation = s) } }
    }

    // ---------- Texto ----------
    fun addText(atMs: Long) {
        val total = _project.value.durationMs
        if (total <= 0L) { message = "Adicione um clipe antes de inserir texto."; return }
        val start = atMs.coerceIn(0L, (total - 500L).coerceAtLeast(0L))
        val t = TextItem(newId(), "Texto", start, minOf(start + 3000L, total))
        edit { it.copy(texts = it.texts + t) }
        selectedTextId = t.id
        selectedClipId = null
    }

    fun updateText(id: String, key: String? = null, f: (TextItem) -> TextItem) =
        edit(key) { p -> p.copy(texts = p.texts.map { if (it.id == id) f(it) else it }) }

    fun deleteText(id: String) {
        edit { p -> p.copy(texts = p.texts.filter { it.id != id }) }
        if (selectedTextId == id) selectedTextId = null
    }

    fun updateAudio(id: String, key: String? = null, f: (AudioItem) -> AudioItem) =
        edit(key) { p -> p.copy(audios = p.audios.map { if (it.id == id) f(it) else it }) }

    fun deleteAudio(id: String) = edit { p -> p.copy(audios = p.audios.filter { it.id != id }) }

    // ---------- Exportação ----------
    fun startExport(s: ExportSettings) {
        val app = getApplication<Application>()
        val p = _project.value
        if (p.clips.isEmpty()) return
        exportState = ExportState.Running(0f)
        val out = File(app.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        val (w, h) = ExportMath.outputSize(p.aspectRatio, s.shortSide)
        val bitrate = ExportMath.videoBitrate(w, h, s.fps, s.codec, s.quality)
        try {
            val composition = CompositionBuilder.build(p, s)
            val encoderFactory = DefaultEncoderFactory.Builder(app)
                .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
                .build()
            val t = Transformer.Builder(app)
                .setVideoMimeType(s.codec.mime)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(encoderFactory)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        progressJob?.cancel()
                        viewModelScope.launch {
                            val uri = withContext(Dispatchers.IO) { saveToGallery(out) }
                            out.delete()
                            exportState = if (uri != null) ExportState.Done(uri)
                            else ExportState.Failed("Exportou, mas não foi possível salvar na galeria (sem espaço?).")
                        }
                    }

                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        progressJob?.cancel()
                        out.delete()
                        exportState = ExportState.Failed(
                            "Falha na exportação (${exportException.errorCodeName}): ${exportException.message}. " +
                                "Tente outro codec, resolução ou FPS menor."
                        )
                    }
                })
                .build()
            transformer = t
            t.start(composition, out.absolutePath)
            progressJob = viewModelScope.launch {
                val holder = ProgressHolder()
                while (isActive) {
                    if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE && exportState is ExportState.Running) {
                        exportState = ExportState.Running(holder.progress / 100f)
                    }
                    delay(400)
                }
            }
        } catch (e: Exception) {
            exportState = ExportState.Failed("Não foi possível iniciar: ${e.message}")
        }
    }

    fun cancelExport() {
        progressJob?.cancel()
        transformer?.cancel()
        exportState = ExportState.Idle
    }

    fun resetExport() {
        if (exportState !is ExportState.Running) exportState = ExportState.Idle
    }

    private fun saveToGallery(file: File): Uri? {
        val resolver = getApplication<Application>().contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "Vortex_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VortexEditor")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            resolver.openOutputStream(uri)?.use { os -> file.inputStream().use { it.copyTo(os) } } ?: return null
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }

    override fun onCleared() {
        transformer?.cancel()
        store.save(_project.value)
        super.onCleared()
    }
}
