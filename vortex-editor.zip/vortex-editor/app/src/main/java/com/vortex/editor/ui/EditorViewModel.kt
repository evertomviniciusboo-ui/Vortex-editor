package com.vortex.editor.ui

import android.app.Application
import android.content.ContentValues
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.os.Build
import android.net.Uri
import android.os.SystemClock
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.vortex.editor.data.ProjectStore
import com.vortex.editor.media.CompositionBuilder
import com.vortex.editor.media.ExportMath
import com.vortex.editor.media.ExportSettings
import com.vortex.editor.media.MediaUtils
import com.vortex.editor.media.Srt
import com.vortex.editor.model.AudioItem
import com.vortex.editor.model.Clip
import com.vortex.editor.model.FxCategory
import com.vortex.editor.model.TransitionType
import com.vortex.editor.model.MediaKind
import com.vortex.editor.model.Project
import com.vortex.editor.model.TextItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val progress: Float) : ExportState
    data class Done(val uri: Uri) : ExportState
    data class Failed(val message: String) : ExportState
}

class EditorViewModel(app: Application, projectId: String) : AndroidViewModel(app) {
    private val store = ProjectStore(app)
    private val _project = MutableStateFlow(store.load(projectId) ?: Project(projectId, "Projeto"))
    val project: StateFlow<Project> = _project.asStateFlow()

    var selectedClipId by mutableStateOf<String?>(null)
    var selectedTextId by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    var copiedClip by mutableStateOf<Clip?>(null)
    var recording by mutableStateOf(false)
        private set
    private var recorder: MediaRecorder? = null
    private var recFile: File? = null
    var exportState by mutableStateOf<ExportState>(ExportState.Idle)
        private set

    private val undoStack = ArrayDeque<Project>()
    private val redoStack = ArrayDeque<Project>()
    private var lastKey: String? = null
    private var lastAt = 0L
    private var transformer: Transformer? = null
    private var progressJob: Job? = null

    init {
        // Salvamento automático (debounce) — projetos sobrevivem a fechamentos inesperados.
        viewModelScope.launch {
            _project.drop(1).debounce(500).collect { p -> withContext(Dispatchers.IO) { store.save(p) } }
        }
    }

    private fun newId() = UUID.randomUUID().toString()

    private fun refreshFlags() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    /** [key] agrupa edições contínuas (ex.: arrastar um slider) em um único passo de desfazer. */
    fun edit(key: String? = null, f: (Project) -> Project) {
        val old = _project.value
        val changed = f(old)
        if (changed == old) return
        val now = SystemClock.elapsedRealtime()
        if (key == null || key != lastKey || now - lastAt > 1200) {
            undoStack.addLast(old)
            if (undoStack.size > 100) undoStack.removeFirst()
            redoStack.clear()
        }
        lastKey = key
        lastAt = now
        _project.value = changed.copy(updatedAt = System.currentTimeMillis())
        refreshFlags()
    }

    fun undo() {
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(_project.value)
        _project.value = prev
        lastKey = null
        refreshFlags()
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(_project.value)
        _project.value = next
        lastKey = null
        refreshFlags()
    }

    fun rename(name: String) = edit("rename") { it.copy(name = name) }
    fun setAspect(a: String) = edit { it.copy(aspect = a) }

    // ---------- Mídia ----------
    fun addMedia(uris: List<Uri>) {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            var failed = 0
            val clips = withContext(Dispatchers.IO) {
                uris.mapNotNull { u ->
                    val info = MediaUtils.probe(ctx, u)
                    when {
                        info == null -> { failed++; null }
                        info.kind == MediaKind.IMAGE ->
                            Clip(newId(), u.toString(), MediaKind.IMAGE, 15_000L, 0L, 3_000L)
                        else -> Clip(newId(), u.toString(), MediaKind.VIDEO, info.durationMs)
                    }
                }
            }
            if (clips.isNotEmpty()) edit { it.copy(clips = it.clips + clips) }
            if (failed > 0) message = "$failed arquivo(s) não puderam ser lidos (formato incompatível?)."
        }
    }

    fun addAudio(uri: Uri, name: String? = null) {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val item = withContext(Dispatchers.IO) {
                val info = MediaUtils.probe(ctx, uri)
                if (info == null || info.kind != MediaKind.VIDEO) null
                else AudioItem(newId(), uri.toString(), name ?: MediaUtils.displayName(ctx, uri), info.durationMs)
            }
            if (item == null) message = "Não foi possível ler esse áudio."
            else edit { it.copy(audios = it.audios + item) }
        }
    }

    // ---------- Clipes ----------
    fun updateClip(id: String, key: String? = null, f: (Clip) -> Clip) =
        edit(key) { p -> p.copy(clips = p.clips.map { if (it.id == id) f(it) else it }) }

    fun deleteClip(id: String) {
        edit { p -> p.copy(clips = p.clips.filter { it.id != id }) }
        if (selectedClipId == id) selectedClipId = null
    }

    fun duplicateClip(id: String) = edit { p ->
        val i = p.clips.indexOfFirst { it.id == id }
        if (i < 0) p else p.copy(clips = p.clips.toMutableList().also { it.add(i + 1, p.clips[i].copy(id = newId())) })
    }

    fun moveClip(id: String, delta: Int) = edit { p ->
        val i = p.clips.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j !in p.clips.indices) p
        else p.copy(clips = p.clips.toMutableList().also { val c = it.removeAt(i); it.add(j, c) })
    }

    /** [posMs] é a posição em tempo de mídia relativa ao início do trecho do clipe. */
    fun splitClip(id: String, posMs: Long) {
        val p = _project.value
        val i = p.clips.indexOfFirst { it.id == id }
        if (i < 0) return
        val c = p.clips[i]
        val sp = c.trimStartMs + posMs
        if (sp - c.trimStartMs < 200 || c.trimEndMs - sp < 200) {
            message = "Posicione o cursor mais ao meio do clipe para dividir."
            return
        }
        val a = c.copy(trimEndMs = sp)
        val b = c.copy(id = newId(), trimStartMs = sp, transition = TransitionType.NONE)
        edit { it.copy(clips = it.clips.toMutableList().also { l -> l[i] = a; l.add(i + 1, b) }) }
    }

    fun copyAdjust(c: Clip) {
        copiedClip = c
        message = "Ajustes de cor copiados."
    }

    fun pasteAdjust(id: String) {
        val src = copiedClip ?: return
        updateClip(id) {
            it.copy(
                brightness = src.brightness, contrast = src.contrast, saturation = src.saturation,
                temperature = src.temperature, vignette = src.vignette, fade = src.fade, sharpen = src.sharpen,
                fx = it.fx.filterNot { f -> f.kind.category == FxCategory.FILTER } +
                    src.fx.filter { f -> f.kind.category == FxCategory.FILTER },
            )
        }
    }

    /** Aplica [f] a todos os clipes (ex.: mesma transição ou mesmos efeitos em todos). */
    fun applyAll(f: (Int, Clip) -> Clip) =
        edit { p -> p.copy(clips = p.clips.mapIndexed { i, c -> f(i, c) }) }

    /** Congela o quadro na posição [posMs] do clipe: cria uma foto de 2 s no ponto. */
    fun freezeFrame(id: String, posMs: Long) {
        val p = _project.value
        val i = p.clips.indexOfFirst { it.id == id }
        if (i < 0) return
        val c = p.clips[i]
        if (c.kind != MediaKind.VIDEO) { message = "Só é possível congelar quadros de vídeo."; return }
        val sp = c.trimStartMs + posMs
        if (sp - c.trimStartMs < 200 || c.trimEndMs - sp < 200) {
            message = "Posicione o cursor mais ao meio do clipe."
            return
        }
        viewModelScope.launch {
            val app = getApplication<Application>()
            val file = withContext(Dispatchers.IO) {
                runCatching {
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(app, Uri.parse(c.uri))
                        val bmp = r.getFrameAtTime(sp * 1000, MediaMetadataRetriever.OPTION_CLOSEST) ?: return@runCatching null
                        val dir = File(app.filesDir, "freeze").apply { mkdirs() }
                        val f = File(dir, "freeze_${newId()}.png")
                        f.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                        f
                    } finally {
                        runCatching { r.release() }
                    }
                }.getOrNull()
            }
            if (file == null) { message = "Não foi possível extrair o quadro."; return@launch }
            val a = c.copy(trimEndMs = sp)
            val still = Clip(
                id = newId(), uri = Uri.fromFile(file).toString(), kind = MediaKind.IMAGE,
                sourceDurationMs = 15_000L, trimStartMs = 0L, trimEndMs = 2_000L, fill = c.fill,
            )
            val b = c.copy(id = newId(), trimStartMs = sp, transition = TransitionType.NONE)
            edit { pr ->
                val idx = pr.clips.indexOfFirst { it.id == id }
                if (idx < 0) pr else pr.copy(clips = pr.clips.toMutableList().also { l ->
                    l[idx] = a; l.add(idx + 1, still); l.add(idx + 2, b)
                })
            }
        }
    }

    // ---------- Texto ----------
    fun addText(atMs: Long) {
        val total = _project.value.durationMs
        if (total <= 0L) { message = "Adicione um clipe antes de inserir texto."; return }
        val start = atMs.coerceIn(0L, (total - 500L).coerceAtLeast(0L))
        val t = TextItem(newId(), "Texto", start, minOf(start + 3000L, total))
        edit { it.copy(texts = it.texts + t) }
        selectedTextId = t.id
        selectedClipId = null
    }

    fun updateText(id: String, key: String? = null, f: (TextItem) -> TextItem) =
        edit(key) { p -> p.copy(texts = p.texts.map { if (it.id == id) f(it) else it }) }

    fun deleteText(id: String) {
        edit { p -> p.copy(texts = p.texts.filter { it.id != id }) }
        if (selectedTextId == id) selectedTextId = null
    }

    fun updateAudio(id: String, key: String? = null, f: (AudioItem) -> AudioItem) =
        edit(key) { p -> p.copy(audios = p.audios.map { if (it.id == id) f(it) else it }) }

    fun deleteAudio(id: String) = edit { p -> p.copy(audios = p.audios.filter { it.id != id }) }

    // ---------- Legendas (SRT) ----------
    fun importSrt(uri: Uri) {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val text = withContext(Dispatchers.IO) {
                runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() }.getOrNull()
            }
            val cues = if (text == null) emptyList() else Srt.parse(text)
            if (cues.isEmpty()) { message = "Nenhuma legenda encontrada no arquivo."; return@launch }
            val items = cues.map { (s, e, t) ->
                TextItem(newId(), t, s, maxOf(e, s + 300L), yPct = 86f, sizePct = 5.5f, bgColor = 0x99000000.toInt())
            }
            edit { it.copy(texts = it.texts + items) }
            message = "${items.size} legenda(s) importada(s)."
        }
    }

    fun exportSrt(uri: Uri) {
        val content = Srt.write(_project.value.texts)
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val ok = withContext(Dispatchers.IO) {
                runCatching { ctx.contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray()) } != null }.getOrDefault(false)
            }
            message = if (ok) "Legendas exportadas." else "Não foi possível salvar o arquivo."
        }
    }

    // ---------- Narração ----------
    fun startRecording() {
        if (recording) return
        val app = getApplication<Application>()
        val dir = File(app.filesDir, "audio").apply { mkdirs() }
        val f = File(dir, "rec_${System.currentTimeMillis()}.m4a")
        try {
            @Suppress("DEPRECATION")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(app) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128_000)
            r.setAudioSamplingRate(44_100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            recFile = f
            recording = true
        } catch (e: Exception) {
            message = "Não foi possível gravar: ${e.message}"
        }
    }

    fun stopRecording() {
        val r = recorder ?: return
        recorder = null
        recording = false
        runCatching { r.stop() }
        runCatching { r.release() }
        val f = recFile ?: return
        addAudio(Uri.fromFile(f), "Narração")
    }

    // ---------- Exportação ----------
    fun startExport(s: ExportSettings) {
        val app = getApplication<Application>()
        val p = _project.value
        if (p.clips.isEmpty()) return
        exportState = ExportState.Running(0f)
        val out = File(app.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        val (w, h) = ExportMath.outputSize(p.aspectRatio, s.shortSide)
        val bitrate = ExportMath.videoBitrate(w, h, s.fps, s.codec, s.quality)
        try {
            val composition = CompositionBuilder.build(p, s)
            val encoderFactory = DefaultEncoderFactory.Builder(app)
                .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
                .build()
            val t = Transformer.Builder(app)
                .setVideoMimeType(s.codec.mime)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(encoderFactory)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        progressJob?.cancel()
                        viewModelScope.launch {
                            val uri = withContext(Dispatchers.IO) { saveToGallery(out) }
                            out.delete()
                            exportState = if (uri != null) ExportState.Done(uri)
                            else ExportState.Failed("Exportou, mas não foi possível salvar na galeria (sem espaço?).")
                        }
                    }

                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        progressJob?.cancel()
                        out.delete()
                        exportState = ExportState.Failed(
                            "Falha na exportação (${exportException.errorCodeName}): ${exportException.message}. " +
                                "Tente outro codec, resolução ou FPS menor."
                        )
                    }
                })
                .build()
            transformer = t
            t.start(composition, out.absolutePath)
            progressJob = viewModelScope.launch {
                val holder = ProgressHolder()
                while (isActive) {
                    if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE && exportState is ExportState.Running) {
                        exportState = ExportState.Running(holder.progress / 100f)
                    }
                    delay(400)
                }
            }
        } catch (e: Exception) {
            exportState = ExportState.Failed("Não foi possível iniciar: ${e.message}")
        }
    }

    fun cancelExport() {
        progressJob?.cancel()
        transformer?.cancel()
        exportState = ExportState.Idle
    }

    fun resetExport() {
        if (exportState !is ExportState.Running) exportState = ExportState.Idle
    }

    private fun saveToGallery(file: File): Uri? {
        val resolver = getApplication<Application>().contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "Vortex_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VortexEditor")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            resolver.openOutputStream(uri)?.use { os -> file.inputStream().use { it.copyTo(os) } } ?: return null
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }

    override fun onCleared() {
        recorder?.let { r -> runCatching { r.stop() }; runCatching { r.release() } }
        transformer?.cancel()
        store.save(_project.value)
        super.onCleared()
    }
}
