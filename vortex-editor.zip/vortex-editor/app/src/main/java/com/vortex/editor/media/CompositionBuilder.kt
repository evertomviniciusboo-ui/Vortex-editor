package com.vortex.editor.media

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import com.google.common.collect.ImmutableList
import com.vortex.editor.model.AudioItem
import com.vortex.editor.model.Clip
import com.vortex.editor.model.MediaKind
import com.vortex.editor.model.Project
import com.vortex.editor.model.TextItem

/** Converte o projeto (modelo não destrutivo) em uma Composition do Media3 Transformer. */
object CompositionBuilder {

    fun build(p: Project, s: ExportSettings): Composition {
        val (w, h) = ExportMath.outputSize(p.aspectRatio, s.shortSide)

        val sequences = mutableListOf(EditedMediaItemSequence(p.clips.map { clipItem(it) }))

        // Trilha de áudio: corta para nunca ultrapassar a duração do vídeo.
        var remaining = p.durationMs
        val audioItems = mutableListOf<EditedMediaItem>()
        for (a in p.audios) {
            if (remaining <= 0L) break
            val len = minOf(a.durationMs, remaining)
            audioItems += audioItem(a, len)
            remaining -= len
        }
        if (audioItems.isNotEmpty()) sequences += EditedMediaItemSequence(audioItems)

        val vfx = mutableListOf<Effect>()
        vfx += Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT)
        vfx += FrameDropEffect.createDefaultFrameDropEffect(s.fps.toFloat())

        val blank = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
        val overlays: List<TextureOverlay> = p.texts
            .filter { it.text.isNotBlank() && it.endMs > it.startMs }
            .map { t -> TimedTextOverlay(t, renderText(t, w), blank, overlaySettings(t)) }
        if (overlays.isNotEmpty()) vfx += OverlayEffect(ImmutableList.copyOf(overlays))

        return Composition.Builder(sequences)
            .setEffects(Effects(emptyList(), vfx))
            .build()
    }

    private fun clipItem(c: Clip): EditedMediaItem {
        val mb = MediaItem.Builder().setUri(c.uri)
        val item: MediaItem = if (c.kind == MediaKind.IMAGE) {
            mb.setImageDurationMs(c.sourceSpanMs).build()
        } else {
            mb.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.trimStartMs)
                    .setEndPositionMs(c.trimEndMs)
                    .build()
            ).build()
        }

        val vfx = mutableListOf<Effect>()
        if (c.brightness != 0f) vfx += Brightness(c.brightness)
        if (c.contrast != 0f) vfx += Contrast(c.contrast)
        if (c.saturation != 0f) vfx += HslAdjustment.Builder().adjustSaturation(c.saturation).build()

        val afx = mutableListOf<AudioProcessor>()
        if (c.kind == MediaKind.VIDEO) {
            if (c.speed != 1f) {
                vfx += SpeedChangeEffect(c.speed)
                afx += SonicAudioProcessor().apply { setSpeed(c.speed); setPitch(1f) }
            }
            if (c.volume != 1f) afx += volumeProcessor(c.volume)
        }

        val b = EditedMediaItem.Builder(item).setEffects(Effects(afx, vfx))
        if (c.kind == MediaKind.IMAGE) b.setFrameRate(30)
        return b.build()
    }

    private fun audioItem(a: AudioItem, lenMs: Long): EditedMediaItem {
        val mi = MediaItem.Builder().setUri(a.uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder().setEndPositionMs(lenMs).build()
            ).build()
        val afx = if (a.volume != 1f) listOf<AudioProcessor>(volumeProcessor(a.volume)) else emptyList()
        return EditedMediaItem.Builder(mi).setRemoveVideo(true).setEffects(Effects(afx, emptyList())).build()
    }

    private fun volumeProcessor(v: Float) = ChannelMixingAudioProcessor().apply {
        for (ch in 1..2) putChannelMixingMatrix(ChannelMixingMatrix.create(ch, ch).scaleBy(v))
    }

    private fun overlaySettings(t: TextItem): OverlaySettings {
        val ax = t.xPct / 50f - 1f
        val ay = 1f - t.yPct / 50f
        return OverlaySettings.Builder()
            .setBackgroundFrameAnchor(ax, ay)
            .setOverlayFrameAnchor(ax, ay)
            .build()
    }

    private fun renderText(t: TextItem, frameW: Int): Bitmap {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = t.color
            textSize = frameW * t.sizePct / 100f
            typeface = if (t.bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            setShadowLayer(textSize * 0.08f, 0f, 0f, Color.BLACK)
        }
        val maxW = (frameW * 0.9f).toInt().coerceAtLeast(10)
        val layout = StaticLayout.Builder.obtain(t.text, 0, t.text.length, paint, maxW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        var lineW = 1f
        for (i in 0 until layout.lineCount) lineW = maxOf(lineW, layout.getLineWidth(i))
        val pad = (paint.textSize * 0.25f).toInt()
        val bmp = Bitmap.createBitmap(lineW.toInt() + pad * 2, layout.height + pad * 2, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.translate(pad - (maxW - lineW) / 2f, pad.toFloat())
        layout.draw(canvas)
        return bmp
    }

    private class TimedTextOverlay(
        private val t: TextItem,
        private val bmp: Bitmap,
        private val blank: Bitmap,
        private val settings: OverlaySettings,
    ) : BitmapOverlay() {
        override fun getBitmap(presentationTimeUs: Long): Bitmap {
            val ms = presentationTimeUs / 1000
            return if (ms >= t.startMs && ms < t.endMs) bmp else blank
        }

        override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings = settings
    }
}
