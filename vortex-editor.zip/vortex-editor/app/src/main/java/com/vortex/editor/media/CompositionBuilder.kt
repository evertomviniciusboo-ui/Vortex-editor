package com.vortex.editor.media

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import com.google.common.collect.ImmutableList
import com.vortex.editor.model.AudioItem
import com.vortex.editor.model.Clip
import com.vortex.editor.model.MediaKind
import com.vortex.editor.model.Project
import com.vortex.editor.model.TextItem

/** Converte o projeto (modelo não destrutivo) em uma Composition do Media3 Transformer. */
object CompositionBuilder {

    fun build(p: Project, s: ExportSettings): Composition {
        val (w, h) = ExportMath.outputSize(p.aspectRatio, s.shortSide)

        val sequences = mutableListOf(EditedMediaItemSequence(p.clips.map { clipItem(it, w, h) }))

        // Trilha de áudio: corta para nunca ultrapassar a duração do vídeo.
        var remaining = p.durationMs
        val audioItems = mutableListOf<EditedMediaItem>()
        for (a in p.audios) {
            if (remaining <= 0L) break
            val len = minOf(a.durationMs, remaining)
            audioItems += audioItem(a, len)
            remaining -= len
        }
        if (audioItems.isNotEmpty()) sequences += EditedMediaItemSequence(audioItems)

        val vfx = mutableListOf<Effect>()
        vfx += FrameDropEffect.createDefaultFrameDropEffect(s.fps.toFloat())
        vfx += Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT)
        if (TimelineMath.needsTransform(p)) {
            vfx += TimelineMatrix(p, w, h)
            vfx += TimelineRgb(p)
        }

        val blank = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
        val overlays: List<TextureOverlay> = p.texts
            .filter { it.text.isNotBlank() && it.endMs > it.startMs }
            .map { t -> TimedTextOverlay(t, renderText(t, w), blank) }
        if (overlays.isNotEmpty()) vfx += OverlayEffect(ImmutableList.copyOf(overlays))

        return Composition.Builder(sequences)
            .setEffects(Effects(emptyList(), vfx))
            .build()
    }

    private fun clipItem(c: Clip, w: Int, h: Int): EditedMediaItem {
        val mb = MediaItem.Builder().setUri(c.uri)
        val item: MediaItem = if (c.kind == MediaKind.IMAGE) {
            mb.setImageDurationMs(c.sourceSpanMs).build()
        } else {
            mb.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.trimStartMs)
                    .setEndPositionMs(c.trimEndMs)
                    .build()
            ).build()
        }

        val vfx = clipEffects(c, export = true, w = w, h = h)

        val afx = mutableListOf<AudioProcessor>()
        if (c.kind == MediaKind.VIDEO) {
            if (c.speed != 1f) afx += SonicAudioProcessor().apply { setSpeed(c.speed); setPitch(1f) }
            if (c.volume != 1f) afx += volumeProcessor(c.volume)
        }

        val b = EditedMediaItem.Builder(item).setEffects(Effects(afx, vfx))
        if (c.kind == MediaKind.IMAGE) b.setFrameRate(30)
        return b.build()
    }

    private fun audioItem(a: AudioItem, lenMs: Long): EditedMediaItem {
        val mi = MediaItem.Builder().setUri(a.uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder().setEndPositionMs(lenMs).build()
            ).build()
        val afx = if (a.volume != 1f) listOf<AudioProcessor>(volumeProcessor(a.volume)) else emptyList()
        return EditedMediaItem.Builder(mi).setRemoveVideo(true).setEffects(Effects(afx, emptyList())).build()
    }

    private fun volumeProcessor(v: Float) = ChannelMixingAudioProcessor().apply {
        for (ch in 1..2) putChannelMixingMatrix(ChannelMixingMatrix.create(ch, ch).scaleBy(v))
    }

    private fun typefaceFor(font: String, bold: Boolean): Typeface {
        val style = if (bold) Typeface.BOLD else Typeface.NORMAL
        return when (font) {
            "serif" -> Typeface.create(Typeface.SERIF, style)
            "mono" -> Typeface.create(Typeface.MONOSPACE, style)
            "cursive" -> Typeface.create("cursive", style)
            "condensed" -> Typeface.create("sans-serif-condensed", style)
            else -> Typeface.create(Typeface.SANS_SERIF, style)
        }
    }

    private fun renderText(t: TextItem, frameW: Int): Bitmap {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = t.color
            textSize = frameW * t.sizePct / 100f
            typeface = typefaceFor(t.font, t.bold)
            setShadowLayer(textSize * 0.08f, 0f, 0f, Color.BLACK)
        }
        val maxW = (frameW * 0.9f).toInt().coerceAtLeast(10)
        val layout = StaticLayout.Builder.obtain(t.text, 0, t.text.length, paint, maxW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        var lineW = 1f
        for (i in 0 until layout.lineCount) lineW = maxOf(lineW, layout.getLineWidth(i))
        val pad = (paint.textSize * 0.25f).toInt().coerceAtLeast(2)
        val bw = lineW.toInt() + pad * 2
        val bh = layout.height + pad * 2
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        if (t.bgColor != 0) {
            val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = t.bgColor }
            canvas.drawRoundRect(RectF(0f, 0f, bw.toFloat(), bh.toFloat()), pad.toFloat(), pad.toFloat(), bg)
        }
        canvas.translate(pad - (maxW - lineW) / 2f, pad.toFloat())
        layout.draw(canvas)
        return bmp
    }

    private class TimedTextOverlay(
        private val t: TextItem,
        private val bmp: Bitmap,
        private val blank: Bitmap,
    ) : BitmapOverlay() {
        private val ax = t.xPct / 50f - 1f
        private val ay = 1f - t.yPct / 50f

        override fun getBitmap(presentationTimeUs: Long): Bitmap {
            val ms = presentationTimeUs / 1000
            return if (ms >= t.startMs && ms < t.endMs) bmp else blank
        }

        override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
            val st = TextAnimMath.state(t, presentationTimeUs / 1000)
            return OverlaySettings.Builder()
                .setBackgroundFrameAnchor(ax, ay - 2f * st.dy)
                .setOverlayFrameAnchor(ax, ay)
                .setAlphaScale(st.alpha)
                .setScale(st.scale, st.scale)
                .build()
        }
    }
}
