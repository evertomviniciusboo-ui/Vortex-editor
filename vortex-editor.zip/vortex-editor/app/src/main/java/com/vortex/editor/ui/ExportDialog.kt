package com.vortex.editor.ui

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vortex.editor.media.Codec
import com.vortex.editor.media.DeviceCaps
import com.vortex.editor.media.ExportMath
import com.vortex.editor.media.ExportSettings
import com.vortex.editor.media.Quality
import com.vortex.editor.model.Project

@Composable
fun ExportDialog(project: Project, vm: EditorViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val state = vm.exportState
    val running = state is ExportState.Running
    DisposableEffect(running) {
        view.keepScreenOn = running
        onDispose { view.keepScreenOn = false }
    }

    var codec by remember { mutableStateOf(Codec.H264) }
    var fps by remember { mutableIntStateOf(30) }
    var shortSide by remember { mutableIntStateOf(1080) }
    var quality by remember { mutableStateOf(Quality.MEDIUM) }

    val ratio = project.aspectRatio
    val hevcOk = remember { DeviceCaps.hasEncoder(Codec.HEVC) }
    val (w, h) = ExportMath.outputSize(ratio, shortSide)
    val supported = remember(codec, w, h, fps) { DeviceCaps.isSupported(codec, w, h, fps) }
    val heightOk = remember(codec, ratio) {
        ExportMath.heights.associate { (s, _) ->
            val (ww, hh) = ExportMath.outputSize(ratio, s)
            s to DeviceCaps.isSupported(codec, ww, hh, 24)
        }
    }
    val fpsOk = remember(codec, w, h) { ExportMath.fpsOptions.associateWith { DeviceCaps.isSupported(codec, w, h, it) } }
    val presets = listOf(
        Triple("TikTok / Reels / Shorts 1080p30", 1080, 30),
        Triple("YouTube 1080p60", 1080, 60),
        Triple("YouTube 4K 30", 2160, 30),
        Triple("WhatsApp 720p", 720, 30),
    )
    val presetOk = remember(ratio) {
        presets.associate { (label, side, f) ->
            val (pw, ph) = ExportMath.outputSize(ratio, side)
            label to DeviceCaps.isSupported(Codec.H264, pw, ph, f)
        }
    }
    val bitrate = ExportMath.videoBitrate(w, h, fps, codec, quality)
    val estMb = ExportMath.estimateBytes(project.durationMs, bitrate) / 1_000_000f

    AlertDialog(
        onDismissRequest = { if (!running) { vm.resetExport(); onDismiss() } },
        title = { Text("Exportar vídeo") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (state) {
                    ExportState.Idle -> {
                        Text("Atalhos (plataformas)", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            presets.forEach { (label, s, f) ->
                                AssistChip(
                                    enabled = presetOk[label] == true,
                                    onClick = { shortSide = s; fps = f; codec = Codec.H264 },
                                    label = { Text(label) },
                                )
                            }
                        }
                        Text("Resolução", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            ExportMath.heights.forEach { (s, label) ->
                                FilterChip(selected = shortSide == s, enabled = heightOk[s] == true, onClick = { shortSide = s }, label = { Text(label) })
                            }
                        }
                        Text("Taxa de quadros (FPS)", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            ExportMath.fpsOptions.forEach { f ->
                                FilterChip(selected = fps == f, enabled = fpsOk[f] == true, onClick = { fps = f }, label = { Text("$f") })
                            }
                        }
                        Text("Codec", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Codec.entries.forEach { c ->
                                FilterChip(
                                    selected = codec == c,
                                    enabled = c != Codec.HEVC || hevcOk,
                                    onClick = { codec = c },
                                    label = { Text(c.label) },
                                )
                            }
                        }
                        Text("Qualidade", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Quality.entries.forEach { q ->
                                FilterChip(selected = quality == q, onClick = { quality = q }, label = { Text(q.label) })
                            }
                        }
                        OutlinedButton(onClick = {
                            DeviceCaps.bestSafe(codec, ratio)?.let { (s, f) -> shortSide = s; fps = f }
                        }) { Text("Usar melhor configuração do aparelho") }

                        Text(
                            "Saída: ${w}×${h} · $fps fps · ${codec.label}\n" +
                                "Bitrate de vídeo ≈ %.1f Mbps · tamanho estimado ≈ %.1f MB".format(bitrate / 1e6f, estMb),
                            fontSize = 13.sp,
                        )
                        if (!supported) {
                            Text(
                                "Este aparelho não anuncia suporte de codificação para essa combinação. Escolha outra resolução/FPS/codec.",
                                color = MaterialTheme.colorScheme.error, fontSize = 12.sp,
                            )
                        }
                        if (shortSide >= 2160 || fps >= 90) {
                            Text(
                                "Aviso: o suporte anunciado pelo codec não garante bom desempenho. 4K e 90/120 FPS podem ser lentos, " +
                                    "esquentar o aparelho ou falhar na renderização completa.",
                                fontSize = 12.sp,
                            )
                        }
                        Text(
                            "O FPS só pode ser reduzido em relação ao original; este app não cria quadros novos (sem interpolação).",
                            fontSize = 11.sp,
                        )
                    }
                    is ExportState.Running -> {
                        LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth())
                        Text("Exportando… ${(state.progress * 100).toInt()}%")
                        Text("Mantenha o app aberto e a tela ligada até terminar.", fontSize = 12.sp)
                    }
                    is ExportState.Done -> {
                        Text("Pronto! Vídeo salvo em Filmes/VortexEditor, sem marca-d'água.")
                        Row2(
                            onOpen = {
                                runCatching {
                                    ctx.startActivity(
                                        Intent(Intent.ACTION_VIEW).setDataAndType(state.uri, "video/mp4")
                                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    )
                                }
                            },
                            onShare = {
                                runCatching {
                                    val send = Intent(Intent.ACTION_SEND).setType("video/mp4")
                                        .putExtra(Intent.EXTRA_STREAM, state.uri)
                                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    ctx.startActivity(Intent.createChooser(send, "Compartilhar vídeo"))
                                }
                            },
                        )
                    }
                    is ExportState.Failed -> {
                        Text(state.message, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = {
            when (state) {
                ExportState.Idle -> Button(
                    enabled = supported && project.clips.isNotEmpty(),
                    onClick = { vm.startExport(ExportSettings(shortSide, fps, codec, quality)) },
                ) { Text("Exportar") }
                is ExportState.Failed -> Button(onClick = { vm.resetExport() }) { Text("Voltar") }
                else -> {}
            }
        },
        dismissButton = {
            when (state) {
                is ExportState.Running -> TextButton(onClick = { vm.cancelExport() }) { Text("Cancelar exportação") }
                else -> TextButton(onClick = { vm.resetExport(); onDismiss() }) { Text("Fechar") }
            }
        },
    )
}

@Composable
private fun Row2(onOpen: () -> Unit, onShare: () -> Unit) {
    androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onOpen) { Text("Abrir") }
        OutlinedButton(onClick = onShare) { Text("Compartilhar") }
    }
}
