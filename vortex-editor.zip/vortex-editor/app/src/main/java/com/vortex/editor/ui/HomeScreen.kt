package com.vortex.editor.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.vortex.editor.data.ProjectStore
import com.vortex.editor.model.Project
import java.util.UUID

@Composable
fun HomeScreen(dark: Boolean, onToggleTheme: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val store = remember { ProjectStore(ctx) }
    var projects by remember { mutableStateOf(store.list()) }
    var showNew by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Project?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Vortex Editor", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = onToggleTheme) {
                        Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "Alternar tema")
                    }
                },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showNew = true },
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("Novo projeto") },
            )
        },
    ) { pad ->
        if (projects.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Nenhum projeto ainda.\nToque em \"Novo projeto\" para começar.",
                    textAlign = TextAlign.Center,
                )
            }
        } else {
            LazyColumn(
                Modifier.padding(pad),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(projects, key = { it.id }) { p ->
                    Card(onClick = { onOpen(p.id) }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            val first = p.clips.firstOrNull()
                            if (first != null) {
                                Thumb(first.uri, first.kind, first.trimStartMs, Modifier.size(72.dp).clip(RoundedCornerShape(8.dp)))
                            } else {
                                Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) { Icon(Icons.Default.Movie, null) }
                            }
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(p.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text("${p.clips.size} clipe(s) · ${fmt(p.durationMs)} · ${p.aspect}")
                            }
                            IconButton(onClick = { toDelete = p }) { Icon(Icons.Default.Delete, "Excluir projeto") }
                        }
                    }
                }
            }
        }
    }

    if (showNew) {
        var name by remember { mutableStateOf("Meu vídeo") }
        var aspect by remember { mutableStateOf("9:16") }
        AlertDialog(
            onDismissRequest = { showNew = false },
            title = { Text("Novo projeto") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Nome") }, singleLine = true)
                    Text("Proporção")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("9:16", "16:9", "1:1", "4:5", "4:3", "21:9").forEach { a ->
                            FilterChip(selected = aspect == a, onClick = { aspect = a }, label = { Text(a) })
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val p = Project(UUID.randomUUID().toString(), name.ifBlank { "Meu vídeo" }, aspect, updatedAt = System.currentTimeMillis())
                    store.save(p)
                    showNew = false
                    onOpen(p.id)
                }) { Text("Criar") }
            },
            dismissButton = { TextButton(onClick = { showNew = false }) { Text("Cancelar") } },
        )
    }

    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Excluir projeto?") },
            text = { Text("\"${p.name}\" será apagado deste aparelho. Os vídeos originais não são afetados.") },
            confirmButton = {
                TextButton(onClick = { store.delete(p.id); projects = store.list(); toDelete = null }) { Text("Excluir") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } },
        )
    }
}
