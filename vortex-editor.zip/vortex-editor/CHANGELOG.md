# Changelog

## 0.2.0
- Transições entre clipes (15), keyframes (zoom/rotação/posição/opacidade), espelhar, preencher tela.
- 20 efeitos de vídeo em GLSL e 9 filtros de cor; ajustes de temperatura, vinheta, fade e nitidez.
- Texto com fundo, animações, fontes, importar/exportar SRT.
- Congelar quadro, narração por microfone, prévia do áudio extra.
- Atalhos de exportação (TikTok/Reels, YouTube, WhatsApp) e mais proporções (4:3, 21:9).
- Prévia em TextureView para aplicar transformações.

## 0.1.0
- Base: projetos, timeline, corte, velocidade, cor básica, texto, música, exportação H.264/HEVC.
