# Vortex Editor v0.3

Editor de vídeo Android, gratuito, offline, sem marca-d'água e sem anúncios. Kotlin + Jetpack Compose + Media3 (ExoPlayer/Transformer).

## Como gerar o APK
1. Suba esta pasta para um repositório GitHub (branch `main`).
2. A aba Actions roda o workflow "Build APK".
3. Baixe o artefato `vortex-debug-apk`, instale no celular.

## Status honesto
Concluído (no código, ainda sem build verificado):
- Seleção de vídeos em grade (MediaStore), ordem de seleção
- Preview com ExoPlayer, filtros e texto aplicados ao vivo
- Timeline com vários clipes: cortar, dividir, mover, excluir
- Velocidade por clipe (0,25x a 4x) com áudio ajustado
- Filtros: Vívido, Cinema, Quente, Frio, P&B
- Texto na tela (cor e tamanho)
- Mudo global
- Exportação 360p a 4K, FPS 24/30/60 ou original, salva em Movies/Vortex

IA (v0.3, 100% no aparelho, sem internet):
- Aba "Editar com IA": vídeo bruto + prompt (ex.: "10 minutos, estilo JP Plays de Minecraft")
- O prompt é interpretado por regras locais: duração alvo, perfil de estilo (Gameplay, Shorts, Vlog, Tutorial, Cinematográfico)
- Análise de áudio (energia por 250 ms) acha silêncios e momentos de pico
- Plano automático: remove silêncio, escolhe os melhores trechos até a duração alvo, acelera trechos calmos, dá zoom nos picos, aplica filtro do perfil
- Exporta sozinho (opcional) ou abre no editor para ajustes
- Limites: não entende pedidos livres como um LLM; não cria conteúdo; se o bruto render menos que o alvo, avisa

Parcial:
- FPS: só reduz quadros, não cria quadros novos (120 FPS exige fonte em 120)
- Filtros e texto valem para o projeto inteiro, não por clipe
- Mudo vale para o projeto inteiro

Pendente:
- Legendas automáticas, detecção de cena por imagem, LLM para entender pedidos livres
- Transições entre clipes, efeitos avançados, camadas de texto/adesivos com timing
- Volume por clipe, trilha de música, legendas automáticas, IA
- Salvar/abrir projetos (Room), exportação em segundo plano (WorkManager)
- Ícone adaptativo e tela de splash
