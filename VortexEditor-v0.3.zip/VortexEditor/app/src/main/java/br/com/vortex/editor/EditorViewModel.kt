@file:OptIn(UnstableApi::class)

package br.com.vortex.editor

import android.app.Application
import android.content.ContentUris
import android.content.ContentValues
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class EditorViewModel(app: Application) : AndroidViewModel(app) {
    var videos by mutableStateOf<List<VideoItem>>(emptyList()); private set
    var clips by mutableStateOf<List<Clip>>(emptyList()); private set
    var selected by mutableIntStateOf(0); private set
    var filter by mutableStateOf(FilterPreset.NONE); private set
    var text by mutableStateOf(TextOverlayState()); private set
    var muted by mutableStateOf(false); private set
    var export by mutableStateOf<ExportState>(ExportState.Idle); private set
    var ai by mutableStateOf<AiState>(AiState.Idle); private set

    private var nextId = 1L
    private var transformer: Transformer? = null
    private var progressJob: Job? = null

    fun loadVideos() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = mutableListOf<VideoItem>()
            val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val proj = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DURATION)
            getApplication<Application>().contentResolver
                .query(base, proj, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")
                ?.use { c ->
                    val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                    val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                    while (c.moveToNext()) {
                        val d = c.getLong(iDur)
                        if (d > 0) list += VideoItem(ContentUris.withAppendedId(base, c.getLong(iId)), d)
                    }
                }
            withContext(Dispatchers.Main) { videos = list }
        }
    }

    fun addClips(items: List<VideoItem>) {
        if (items.isEmpty()) return
        clips = clips + items.map { Clip(nextId++, it.uri, it.durationMs) }
    }

    fun select(i: Int) { if (i in clips.indices) selected = i }

    private fun edit(f: (Clip) -> Clip) {
        if (selected !in clips.indices) return
        clips = clips.toMutableList().also { it[selected] = f(it[selected]) }
    }

    fun trim(s: Long, e: Long) {
        val c = clips.getOrNull(selected) ?: return
        if (Timeline.validTrim(s, e, c.durationMs)) edit { it.copy(startMs = s, endMs = e) }
    }

    fun split(positionMs: Long?) {
        val c = clips.getOrNull(selected) ?: return
        val rel = positionMs ?: ((c.endMs - c.startMs) / 2)
        val at = Timeline.splitPoint(c.startMs, c.endMs, c.startMs + rel) ?: return
        val list = clips.toMutableList()
        list[selected] = c.copy(endMs = at)
        list.add(selected + 1, c.copy(id = nextId++, startMs = at))
        clips = list
    }

    fun delete() {
        if (selected !in clips.indices) return
        clips = clips.toMutableList().also { it.removeAt(selected) }
        selected = selected.coerceIn(0, (clips.size - 1).coerceAtLeast(0))
    }

    fun move(dir: Int) {
        val to = selected + dir
        if (selected !in clips.indices || to !in clips.indices) return
        val list = clips.toMutableList()
        list.add(to, list.removeAt(selected))
        clips = list
        selected = to
    }

    fun setSpeed(s: Float) = edit { it.copy(speed = s) }
    fun setFilter(f: FilterPreset) { filter = f }
    fun setText(t: TextOverlayState) { text = t }
    fun toggleMute() { muted = !muted }
    fun resetExport() { export = ExportState.Idle }

    fun runAi(source: Uri, prompt: String, autoExport: Boolean, onReady: () -> Unit) {
        if (ai is AiState.Working) return
        val app = getApplication<Application>()
        val req = PromptParser.parse(prompt)
        ai = AiState.Working("Lendo o vídeo…", 0f)
        viewModelScope.launch {
            try {
                val (dur, plan) = withContext(Dispatchers.IO) {
                    val r = MediaMetadataRetriever()
                    val d = try {
                        r.setDataSource(app, source)
                        r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    } finally { r.release() }
                    if (d <= 0) error("Não consegui ler a duração do vídeo.")
                    val energy = AudioAnalyzer.energy(app, source, d, 250L) { p ->
                        ai = AiState.Working("Analisando o áudio…", p)
                    }
                    ai = AiState.Working("Planejando os cortes…", 1f)
                    d to Planner.plan(energy, 250L, d, req)
                }
                clips = plan.segments.map { Clip(nextId++, source, dur, it.startMs, it.endMs, it.speed, it.zoom) }
                selected = 0
                filter = req.preset.filter
                text = TextOverlayState()
                ai = AiState.Ready(
                    "${clips.size} cortes · duração final ${fmt(plan.outputMs)}" +
                        plan.notes.joinToString("") { "\n$it" }
                )
                onReady()
                if (autoExport) startExport(ExportOptions(vertical = req.preset.vertical))
            } catch (e: Exception) {
                ai = AiState.Failed(e.message ?: "Falha ao gerar a edição.")
            }
        }
    }

    fun startExport(opt: ExportOptions) {
        if (clips.isEmpty() || export is ExportState.Running) return
        val app = getApplication<Application>()
        val out = File(app.cacheDir, "vortex_${System.currentTimeMillis()}.mp4")
        val items = clips.map { c ->
            EditedMediaItem.Builder(c.toMediaItem())
                .setRemoveAudio(muted)
                .setEffects(Fx.clipEffects(c))
                .build()
        }
        val global = buildList<Effect> {
            addAll(Fx.filter(filter))
            addAll(Fx.text(text))
            opt.fps?.let { add(FrameDropEffect.createDefaultFrameDropEffect(it.toFloat())) }
            if (opt.vertical) add(Presentation.createForAspectRatio(9f / 16f, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
            add(Presentation.createForHeight(opt.height))
        }
        val composition = Composition.Builder(listOf(EditedMediaItemSequence(items)))
            .setEffects(Effects(emptyList(), global))
            .build()

        val t = Transformer.Builder(app)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    progressJob?.cancel()
                    viewModelScope.launch(Dispatchers.IO) {
                        val uri = saveToGallery(out)
                        withContext(Dispatchers.Main) {
                            export = if (uri != null) ExportState.Done(uri)
                            else ExportState.Failed("Não foi possível salvar na galeria.")
                        }
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    progressJob?.cancel()
                    export = ExportState.Failed(exportException.message ?: "Falha na exportação.")
                }
            })
            .build()
        transformer = t
        export = ExportState.Running(0f)
        t.start(composition, out.absolutePath)

        progressJob = viewModelScope.launch {
            val holder = ProgressHolder()
            while (isActive) {
                if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    export = ExportState.Running(holder.progress / 100f)
                }
                delay(300)
            }
        }
    }

    fun cancelExport() {
        transformer?.cancel()
        progressJob?.cancel()
        export = ExportState.Idle
    }

    private fun saveToGallery(file: File): Uri? {
        val resolver = getApplication<Application>().contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Vortex")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        resolver.openOutputStream(uri)?.use { o -> file.inputStream().use { it.copyTo(o) } }
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        file.delete()
        return uri
    }

    override fun onCleared() {
        transformer?.cancel()
        super.onCleared()
    }
}
