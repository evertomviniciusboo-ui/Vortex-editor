package br.com.vortex.editor

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import java.text.Normalizer
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

enum class StylePreset(
    val label: String,
    val maxSegMs: Long,
    val mergeGapMs: Long,
    val silenceRelDb: Double,
    val quietRelDb: Double,
    val quietSpeed: Float,
    val zoomPeaks: Boolean,
    val filter: FilterPreset,
    val vertical: Boolean = false
) {
    GAMEPLAY("Gameplay dinâmico", 12_000, 700, -30.0, -18.0, 1.5f, true, FilterPreset.VIVID),
    SHORTS("Shorts vertical", 6_000, 500, -28.0, -16.0, 1.25f, true, FilterPreset.VIVID, true),
    VLOG("Vlog", 20_000, 1_000, -35.0, -22.0, 1f, false, FilterPreset.WARM),
    TUTORIAL("Tutorial", 40_000, 1_500, -40.0, -28.0, 1f, false, FilterPreset.NONE),
    CINEMATIC("Cinematográfico", 15_000, 1_000, -40.0, -26.0, 1f, false, FilterPreset.CINEMA)
}

data class StyleRequest(val targetMs: Long?, val preset: StylePreset, val notes: List<String>)

data class Segment(val startMs: Long, val endMs: Long, val speed: Float, val zoom: Float)

data class PlanResult(val segments: List<Segment>, val outputMs: Long, val notes: List<String>)

object PromptParser {
    private val durationRx =
        Regex("""(\d+(?:[.,]\d+)?)\s*(horas?|hrs?|h|minutos?|mins?|segundos?|segs?|s)\b""")

    fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    fun parse(prompt: String): StyleRequest {
        val t = norm(prompt)
        val notes = mutableListOf<String>()
        val target = durationRx.find(t)?.let {
            val v = it.groupValues[1].replace(',', '.').toDouble()
            val u = it.groupValues[2]
            val ms = when {
                u.startsWith("h") -> v * 3_600_000
                u.startsWith("m") -> v * 60_000
                else -> v * 1_000
            }
            ms.toLong()
        }
        val preset = when {
            listOf("short", "tiktok", "reels", "vertical").any { it in t } -> StylePreset.SHORTS
            listOf("minecraft", "jp plays", "jpplays", "gameplay", "gamer", "jogo", "lets play", "game")
                .any { it in t } -> {
                notes += "Uso um perfil de ritmo (cortes rápidos, zoom nos picos), não uma cópia exata de nenhum criador."
                StylePreset.GAMEPLAY
            }
            "vlog" in t -> StylePreset.VLOG
            "tutorial" in t || "aula" in t -> StylePreset.TUTORIAL
            "cinema" in t -> StylePreset.CINEMATIC
            else -> {
                if (t.isNotBlank()) notes += "Estilo não reconhecido; usei o perfil Vlog."
                StylePreset.VLOG
            }
        }
        return StyleRequest(target, preset, notes)
    }
}

object Planner {
    private data class Cand(
        val s: Long, val e: Long, val score: Double, val gap: Boolean, val rel: Double
    )

    fun plan(energy: FloatArray, windowMs: Long, durationMs: Long, req: StyleRequest): PlanResult {
        val p = req.preset
        val notes = req.notes.toMutableList()
        if (energy.isEmpty() || durationMs <= 0) {
            notes += "Não consegui analisar o áudio; mantive o vídeo inteiro."
            return PlanResult(listOf(Segment(0, durationMs, 1f, 1f)), durationMs, notes)
        }
        val n = energy.size
        val db = DoubleArray(n) { 20 * log10(max(energy[it].toDouble(), 1e-6)) }
        val sorted = db.sorted()
        val ref = sorted[((sorted.size - 1) * 0.95).toInt()]
        val rel = DoubleArray(n) { db[it] - ref }
        val loud = BooleanArray(n) { rel[it] > p.silenceRelDb }
        val gapWin = (p.mergeGapMs / windowMs).toInt().coerceAtLeast(1)

        val moments = mutableListOf<IntRange>()
        var i = 0
        while (i < n) {
            if (!loud[i]) { i++; continue }
            var lastLoud = i
            var k = i
            while (k < n && k - lastLoud <= gapWin) { if (loud[k]) lastLoud = k; k++ }
            moments += i..lastLoud
            i = lastLoud + 1
        }

        val cands = mutableListOf<Cand>()
        val chunkWin = (p.maxSegMs / windowMs).toInt().coerceAtLeast(1)
        fun addRange(a: Int, bExcl: Int, gap: Boolean) {
            var s = a
            while (s < bExcl) {
                val e = min(bExcl, s + chunkWin)
                val len = (e - s) * windowMs
                if (len >= (if (gap) 300 else 600)) {
                    var sum = 0.0
                    var peak = -999.0
                    for (w in s until e) { sum += rel[w]; peak = max(peak, rel[w]) }
                    val mean = sum / (e - s)
                    cands += Cand(
                        s * windowMs, min(e * windowMs, durationMs),
                        mean + 0.5 * peak - (if (gap) 100 else 0), gap, mean
                    )
                }
                s = e
            }
        }
        var prev = 0
        for (m in moments) {
            val a = max(prev, m.first - 1)
            val b = min(n, m.last + 2)
            addRange(prev, a, true)
            addRange(a, b, false)
            prev = b
        }
        addRange(prev, n, true)

        fun speedOf(c: Cand) = if (c.rel < p.quietRelDb) p.quietSpeed else 1f
        fun outLen(c: Cand) = ((c.e - c.s) / speedOf(c)).toLong()

        val target = req.targetMs
        val chosen: List<Cand> = if (target == null) {
            cands.filter { !it.gap }
        } else {
            val acc = mutableListOf<Cand>()
            var total = 0L
            for (c in cands.sortedByDescending { it.score }) {
                val l = outLen(c)
                if (total + l > target) continue
                acc += c
                total += l
            }
            acc
        }
        if (chosen.isEmpty()) {
            notes += "Não achei trechos claros; mantive o vídeo inteiro."
            return PlanResult(listOf(Segment(0, durationMs, 1f, 1f)), durationMs, notes)
        }
        val scores = chosen.filter { !it.gap }.map { it.score }.sorted()
        val thr = if (scores.isEmpty()) Double.MAX_VALUE else scores[((scores.size - 1) * 0.75).toInt()]
        val segs = chosen.sortedBy { it.s }.map {
            Segment(it.s, it.e, speedOf(it), if (p.zoomPeaks && !it.gap && it.score >= thr) 1.12f else 1f)
        }
        val total = segs.sumOf { ((it.endMs - it.startMs) / it.speed).toLong() }
        if (target != null && total < target * 0.9) {
            notes += "O material bruto rendeu só ${total / 1000}s; não dá para chegar a ${target / 1000}s sem repetir conteúdo."
        }
        return PlanResult(segs, total, notes)
    }
}

object AudioAnalyzer {
    fun energy(
        ctx: Context, uri: Uri, durationMs: Long, windowMs: Long, onProgress: (Float) -> Unit
    ): FloatArray {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    track = i; break
                }
            }
            if (track < 0) return FloatArray(0)
            ex.selectTrack(track)
            val fmt = ex.getTrackFormat(track)
            var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val c = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()

            val nWin = (durationMs / windowMs).toInt() + 2
            val sums = DoubleArray(nWin)
            val counts = LongArray(nWin)
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            while (!outDone) {
                if (!inDone) {
                    val ib = c.dequeueInputBuffer(10_000)
                    if (ib >= 0) {
                        val buf = c.getInputBuffer(ib)!!
                        val sz = ex.readSampleData(buf, 0)
                        if (sz < 0) {
                            c.queueInputBuffer(ib, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            c.queueInputBuffer(ib, 0, sz, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val ob = c.dequeueOutputBuffer(info, 10_000)
                if (ob >= 0) {
                    val out = c.getOutputBuffer(ob)!!
                    out.position(info.offset)
                    out.limit(info.offset + info.size)
                    val sb = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                    val frames = sb.remaining() / ch
                    val startFrame = info.presentationTimeUs * rate / 1_000_000L
                    val winFrames = (rate * windowMs / 1000L).coerceAtLeast(1)
                    for (f in 0 until frames) {
                        var acc = 0.0
                        for (k in 0 until ch) acc += sb.get(f * ch + k) / 32768.0
                        val m = acc / ch
                        val w = ((startFrame + f) / winFrames).toInt().coerceIn(0, nWin - 1)
                        sums[w] += m * m
                        counts[w]++
                    }
                    onProgress((info.presentationTimeUs / 1000f / durationMs).coerceIn(0f, 1f))
                    c.releaseOutputBuffer(ob, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (ob == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = c.outputFormat
                    rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            return FloatArray(nWin) { if (counts[it] > 0) sqrt(sums[it] / counts[it]).toFloat() else 0f }
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            codec?.release()
            ex.release()
        }
    }
}
