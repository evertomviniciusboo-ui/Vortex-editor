@file:OptIn(UnstableApi::class)

package br.com.vortex.editor

import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextOverlay
import androidx.media3.transformer.Effects
import com.google.common.collect.ImmutableList

object Fx {
    fun filter(f: FilterPreset): List<Effect> = when (f) {
        FilterPreset.NONE -> emptyList()
        FilterPreset.VIVID -> listOf(
            HslAdjustment.Builder().adjustSaturation(35f).build(),
            Contrast(0.12f)
        )
        FilterPreset.CINEMA -> listOf(
            Contrast(0.25f),
            HslAdjustment.Builder().adjustSaturation(-20f).build(),
            Brightness(-0.05f)
        )
        FilterPreset.WARM -> listOf(RgbAdjustment.Builder().setRedScale(1.12f).setBlueScale(0.88f).build())
        FilterPreset.COLD -> listOf(RgbAdjustment.Builder().setRedScale(0.88f).setBlueScale(1.12f).build())
        FilterPreset.BW -> listOf(RgbFilter.createGrayscaleFilter())
    }

    fun text(t: TextOverlayState): List<Effect> {
        if (t.text.isBlank()) return emptyList()
        val s = SpannableString(t.text)
        s.setSpan(ForegroundColorSpan(t.color), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(AbsoluteSizeSpan(t.sizePx), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val settings = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, -0.7f).build()
        return listOf(OverlayEffect(ImmutableList.of(TextOverlay.createStaticTextOverlay(s, settings))))
    }

    fun clipEffects(c: Clip): Effects {
        val audio = mutableListOf<AudioProcessor>()
        val video = mutableListOf<Effect>()
        if (c.speed != 1f) {
            audio += SonicAudioProcessor().apply { setSpeed(c.speed) }
            video += SpeedChangeEffect(c.speed)
        }
        if (c.zoom != 1f) video += ScaleAndRotateTransformation.Builder().setScale(c.zoom, c.zoom).build()
        return Effects(audio, video)
    }
}

fun Clip.toMediaItem(): MediaItem = MediaItem.Builder()
    .setUri(uri)
    .setClippingConfiguration(
        MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs)
            .setEndPositionMs(endMs)
            .build()
    )
    .build()
