package br.com.vortex.editor

import android.net.Uri

data class VideoItem(val uri: Uri, val durationMs: Long)

data class Clip(
    val id: Long,
    val uri: Uri,
    val durationMs: Long,
    val startMs: Long = 0L,
    val endMs: Long = durationMs,
    val speed: Float = 1f,
    val zoom: Float = 1f
) {
    val outputMs: Long get() = Timeline.outputMs(startMs, endMs, speed)
}

enum class FilterPreset(val label: String) {
    NONE("Original"), VIVID("Vívido"), CINEMA("Cinema"), WARM("Quente"), COLD("Frio"), BW("P&B")
}

data class TextOverlayState(
    val text: String = "",
    val color: Int = 0xFFFFFFFF.toInt(),
    val sizePx: Int = 64
)

data class ExportOptions(val height: Int = 1080, val fps: Int? = null, val vertical: Boolean = false)

sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val progress: Float) : ExportState
    data class Done(val uri: Uri) : ExportState
    data class Failed(val message: String) : ExportState
}

sealed interface AiState {
    data object Idle : AiState
    data class Working(val stage: String, val progress: Float) : AiState
    data class Ready(val summary: String) : AiState
    data class Failed(val message: String) : AiState
}

object Timeline {
    const val MIN_CLIP_MS = 300L

    fun outputMs(startMs: Long, endMs: Long, speed: Float): Long =
        ((endMs - startMs) / speed).toLong()

    fun splitPoint(startMs: Long, endMs: Long, atMs: Long): Long? =
        if (atMs - startMs >= MIN_CLIP_MS && endMs - atMs >= MIN_CLIP_MS) atMs else null

    fun validTrim(startMs: Long, endMs: Long, durationMs: Long): Boolean =
        startMs >= 0 && endMs <= durationMs && endMs - startMs >= MIN_CLIP_MS
}
