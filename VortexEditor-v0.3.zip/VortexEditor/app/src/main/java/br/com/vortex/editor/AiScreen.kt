package br.com.vortex.editor

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val examples = listOf(
    "Gameplay 10 min" to "Faça esse vídeo ter 10 minutos com estilo de edição do JP Plays de Minecraft",
    "Short 30 s" to "Transforme em um short vertical de 30 segundos",
    "Vlog 5 min" to "Deixe em um vlog de 5 minutos",
    "Tutorial 8 min" to "Faça um tutorial de 8 minutos"
)

@Composable
fun AiScreen(vm: EditorViewModel, onBack: () -> Unit, onOpenEditor: () -> Unit) {
    var source by remember { mutableStateOf<Uri?>(null) }
    var prompt by remember { mutableStateOf("") }
    var auto by remember { mutableStateOf(true) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { source = it }
    val req = remember(prompt) { PromptParser.parse(prompt) }
    val working = vm.ai is AiState.Working

    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Logo()
            Text("  Editor com IA", fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("Voltar") }
        }
        Button(onClick = { pick.launch("video/*") }, modifier = Modifier.fillMaxWidth()) {
            Text(if (source == null) "Escolher vídeo bruto" else "Vídeo escolhido · trocar")
        }
        OutlinedTextField(
            value = prompt, onValueChange = { prompt = it }, minLines = 3,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Ex.: faça esse vídeo ter 10 minutos com estilo de edição do JP Plays de Minecraft") }
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            examples.forEach { (label, text) ->
                FilterChip(selected = false, onClick = { prompt = text }, label = { Text(label) })
            }
        }
        if (prompt.isNotBlank()) {
            Text(
                "Entendi: ${req.preset.label}" +
                    (req.targetMs?.let { " · alvo ${fmt(it)}" } ?: "") +
                    (if (req.preset.vertical) " · vertical 9:16" else ""),
                color = Cyan, fontSize = 13.sp
            )
            req.notes.forEach { Text(it, fontSize = 12.sp) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = auto, onCheckedChange = { auto = it })
            Text("  Exportar automaticamente")
        }
        Button(
            onClick = { source?.let { vm.runAi(it, prompt, auto, onOpenEditor) } },
            enabled = source != null && prompt.isNotBlank() && !working,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Gerar edição") }

        when (val s = vm.ai) {
            is AiState.Working -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(s.stage)
                LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
            }
            is AiState.Ready -> Text(s.summary)
            is AiState.Failed -> Text(s.message, color = MaterialTheme.colorScheme.error)
            AiState.Idle -> {}
        }
    }
}
