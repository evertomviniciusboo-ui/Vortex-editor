package br.com.vortex.editor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.ImageLoader
import coil.decode.VideoFrameDecoder

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { VortexTheme { VortexApp() } }
    }
}

enum class Screen { PICKER, EDITOR, AI }

@Composable
fun VortexApp(vm: EditorViewModel = viewModel()) {
    val ctx = LocalContext.current
    val loader = remember {
        ImageLoader.Builder(ctx).components { add(VideoFrameDecoder.Factory()) }.build()
    }
    var screen by rememberSaveable { mutableStateOf(Screen.PICKER) }
    BackHandler(enabled = screen != Screen.PICKER) { screen = Screen.PICKER }
    Surface(Modifier.fillMaxSize(), color = Bg) {
        when {
            screen == Screen.AI -> AiScreen(
                vm, onBack = { screen = Screen.PICKER }, onOpenEditor = { screen = Screen.EDITOR }
            )
            screen == Screen.EDITOR && vm.clips.isNotEmpty() -> EditorScreen(
                vm, loader, onAdd = { screen = Screen.PICKER }, onAi = { screen = Screen.AI }
            )
            else -> PickerScreen(
                vm, loader,
                onDone = { screen = if (vm.clips.isNotEmpty()) Screen.EDITOR else Screen.PICKER },
                onAi = { screen = Screen.AI }
            )
        }
    }
}
