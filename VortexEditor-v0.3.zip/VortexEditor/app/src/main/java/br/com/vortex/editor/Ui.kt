@file:OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)

package br.com.vortex.editor

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.ImageLoader
import coil.compose.AsyncImage

val Cyan = Color(0xFF00E5FF)
val Bg = Color(0xFF0B0B0F)
val Panel = Color(0xFF16161D)

@Composable
fun VortexTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Cyan, onPrimary = Color.Black, background = Bg, onBackground = Color.White,
        surface = Panel, onSurface = Color.White, secondaryContainer = Color(0xFF003A44)
    ),
    content = content
)

fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

fun spd(s: Float): String = if (s % 1f == 0f) "${s.toInt()}x" else "${s}x"

@Composable
fun Logo() {
    Box(Modifier.size(32.dp).background(Cyan, CircleShape), contentAlignment = Alignment.Center) {
        Text("V", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

@Composable
fun PickerScreen(vm: EditorViewModel, loader: ImageLoader, onDone: () -> Unit, onAi: () -> Unit) {
    val ctx = LocalContext.current
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
    else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(granted) { if (granted) vm.loadVideos() else launcher.launch(perm) }
    val picked = remember { mutableStateListOf<VideoItem>() }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Logo()
            Text("  Novo projeto", fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Button(onClick = onAi) { Text("Editar com IA") }
        }
        if (!granted) {
            Column(Modifier.weight(1f).fillMaxWidth(), Arrangement.Center, Alignment.CenterHorizontally) {
                Text("Permita o acesso aos seus vídeos para começar.", textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { launcher.launch(perm) }) { Text("Permitir acesso") }
            }
        } else {
            LazyVerticalGrid(
                GridCells.Fixed(3), Modifier.weight(1f),
                contentPadding = PaddingValues(2.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                items(vm.videos, key = { it.uri.toString() }) { v ->
                    val n = picked.indexOf(v)
                    Box(Modifier.aspectRatio(1f).clickable { if (n >= 0) picked.remove(v) else picked.add(v) }) {
                        AsyncImage(
                            model = v.uri, imageLoader = loader, contentDescription = null,
                            contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                        )
                        Text(
                            fmt(v.durationMs), fontSize = 11.sp,
                            modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp)
                                .background(Color(0x99000000), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp)
                        )
                        if (n >= 0) Box(
                            Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp).background(Cyan, CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Text("${n + 1}", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
        Button(
            onClick = { vm.addClips(picked.toList()); picked.clear(); onDone() },
            enabled = picked.isNotEmpty() || vm.clips.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) { Text(if (picked.isEmpty()) "Voltar ao editor" else "Adicionar ${picked.size}") }
    }
}

private data class Tool(val icon: ImageVector, val label: String, val onClick: () -> Unit)
private enum class Dlg { TRIM, SPEED, FILTER, TEXT, EXPORT }

@Composable
fun EditorScreen(vm: EditorViewModel, loader: ImageLoader, onAdd: () -> Unit, onAi: () -> Unit) {
    val ctx = LocalContext.current
    val exo = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { exo.release() } }

    LaunchedEffect(vm.clips, vm.filter, vm.text) {
        val items = vm.clips.map { it.toMediaItem() }
        if (items.isEmpty()) { exo.clearMediaItems(); return@LaunchedEffect }
        val idx = exo.currentMediaItemIndex.coerceIn(0, items.lastIndex)
        exo.setVideoEffects(Fx.filter(vm.filter) + Fx.text(vm.text))
        exo.setMediaItems(items, idx, exo.currentPosition)
        exo.prepare()
    }
    LaunchedEffect(vm.muted) { exo.volume = if (vm.muted) 0f else 1f }
    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onEvents(p: Player, e: Player.Events) {
                if (e.containsAny(Player.EVENT_MEDIA_ITEM_TRANSITION, Player.EVENT_TIMELINE_CHANGED)) {
                    p.setPlaybackSpeed(vm.clips.getOrNull(p.currentMediaItemIndex)?.speed ?: 1f)
                }
            }
        }
        exo.addListener(l)
        onDispose { exo.removeListener(l) }
    }

    var dialog by remember { mutableStateOf<Dlg?>(null) }
    val sel = vm.clips.getOrNull(vm.selected)

    val tools = listOf(
        Tool(Icons.Default.ContentCut, "Cortar") { dialog = Dlg.TRIM },
        Tool(Icons.Default.CallSplit, "Dividir") {
            vm.split(if (exo.currentMediaItemIndex == vm.selected) exo.currentPosition else null)
        },
        Tool(Icons.Default.Speed, "Velocidade") { dialog = Dlg.SPEED },
        Tool(Icons.Default.AutoFixHigh, "Filtros") { dialog = Dlg.FILTER },
        Tool(Icons.Default.TextFields, "Texto") { dialog = Dlg.TEXT },
        Tool(if (vm.muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
            if (vm.muted) "Com áudio" else "Mudo") { vm.toggleMute() },
        Tool(Icons.AutoMirrored.Filled.ArrowBack, "Antes") { vm.move(-1) },
        Tool(Icons.AutoMirrored.Filled.ArrowForward, "Depois") { vm.move(1) },
        Tool(Icons.Default.Delete, "Excluir") { vm.delete() }
    )

    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Logo()
            Text("  Vortex Editor", fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            TextButton(onClick = onAi) { Text("IA") }
            Button(onClick = { dialog = Dlg.EXPORT }) { Text("Exportar") }
        }
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    player = exo
                    useController = true
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                }
            },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
        LazyRow(
            Modifier.fillMaxWidth().height(84.dp).padding(vertical = 6.dp),
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            itemsIndexed(vm.clips, key = { _, c -> c.id }) { i, c ->
                val isSel = i == vm.selected
                val shape = RoundedCornerShape(8.dp)
                Box(
                    Modifier.width((c.outputMs / 1000f * 20f).coerceIn(72f, 260f).dp).fillMaxHeight()
                        .clip(shape)
                        .then(if (isSel) Modifier.border(2.dp, Cyan, shape) else Modifier)
                        .clickable { vm.select(i); exo.seekTo(i, 0) }
                ) {
                    AsyncImage(
                        model = c.uri, imageLoader = loader, contentDescription = null,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                    Text(
                        fmt(c.outputMs) + if (c.speed != 1f) " · ${spd(c.speed)}" else "",
                        fontSize = 11.sp,
                        modifier = Modifier.align(Alignment.BottomStart).padding(4.dp)
                            .background(Color(0x99000000), RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp)
                    )
                }
            }
            item {
                IconButton(onClick = onAdd, modifier = Modifier.size(72.dp).background(Panel, RoundedCornerShape(8.dp))) {
                    Icon(Icons.Default.Add, "Adicionar vídeo", tint = Cyan)
                }
            }
        }
        LazyRow(
            Modifier.fillMaxWidth().background(Panel).padding(vertical = 8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp)
        ) {
            items(tools) { t ->
                Column(
                    Modifier.width(68.dp).clickable { t.onClick() }.padding(4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(t.icon, t.label, tint = Cyan)
                    Text(t.label, fontSize = 11.sp)
                }
            }
        }
    }

    when (dialog) {
        Dlg.TRIM -> sel?.let { c ->
            var r by remember(c.id) { mutableStateOf(c.startMs.toFloat()..c.endMs.toFloat()) }
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text("Cortar clipe") },
                text = {
                    Column {
                        RangeSlider(value = r, onValueChange = { r = it }, valueRange = 0f..c.durationMs.toFloat())
                        Text("${fmt(r.start.toLong())} – ${fmt(r.endInclusive.toLong())}")
                    }
                },
                confirmButton = {
                    TextButton(onClick = { vm.trim(r.start.toLong(), r.endInclusive.toLong()); dialog = null }) { Text("Aplicar") }
                },
                dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancelar") } }
            )
        }
        Dlg.SPEED -> PickDialog("Velocidade", listOf(0.25f, 0.5f, 1f, 1.5f, 2f, 4f), sel?.speed ?: 1f, ::spd,
            { vm.setSpeed(it); dialog = null }) { dialog = null }
        Dlg.FILTER -> PickDialog("Filtros", FilterPreset.entries, vm.filter, { it.label },
            { vm.setFilter(it); dialog = null }) { dialog = null }
        Dlg.TEXT -> {
            var t by remember { mutableStateOf(vm.text) }
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text("Texto na tela") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(t.text, { t = t.copy(text = it) }, placeholder = { Text("Digite seu texto") })
                        Chips(listOf(0xFFFFFFFF, 0xFF00E5FF, 0xFFFFEB3B, 0xFFFF5252).map { it.toInt() },
                            t.color, { when (it) { 0xFFFFFFFF.toInt() -> "Branco"; 0xFF00E5FF.toInt() -> "Ciano"; 0xFFFFEB3B.toInt() -> "Amarelo"; else -> "Vermelho" } }) { t = t.copy(color = it) }
                        Chips(listOf(40, 64, 96), t.sizePx, { when (it) { 40 -> "Pequeno"; 64 -> "Médio"; else -> "Grande" } }) { t = t.copy(sizePx = it) }
                    }
                },
                confirmButton = { TextButton(onClick = { vm.setText(t); dialog = null }) { Text("Aplicar") } },
                dismissButton = {
                    TextButton(onClick = { vm.setText(TextOverlayState()); dialog = null }) { Text("Remover") }
                }
            )
        }
        Dlg.EXPORT -> {
            var o by remember { mutableStateOf(ExportOptions()) }
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text("Exportar vídeo") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Resolução")
                        Chips(listOf(360, 480, 720, 1080, 1440, 2160), o.height,
                            { if (it == 2160) "4K" else "${it}p" }) { o = o.copy(height = it) }
                        Text("Quadros por segundo")
                        Chips(listOf<Int?>(null, 24, 30, 60), o.fps, { it?.toString() ?: "Original" }) { o = o.copy(fps = it) }
                        Text("Reduz FPS quando o vídeo tem mais quadros; não cria quadros novos.", fontSize = 12.sp)
                    }
                },
                confirmButton = { TextButton(onClick = { dialog = null; vm.startExport(o) }) { Text("Exportar") } },
                dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancelar") } }
            )
        }
        null -> {}
    }

    when (val s = vm.export) {
        is ExportState.Running -> AlertDialog(
            onDismissRequest = {},
            title = { Text("Exportando…") },
            text = { LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { TextButton(onClick = { vm.cancelExport() }) { Text("Cancelar") } }
        )
        is ExportState.Done -> AlertDialog(
            onDismissRequest = { vm.resetExport() },
            title = { Text("Vídeo salvo") },
            text = { Text("Ele está na galeria, em Movies/Vortex.") },
            confirmButton = { TextButton(onClick = { vm.resetExport() }) { Text("OK") } }
        )
        is ExportState.Failed -> AlertDialog(
            onDismissRequest = { vm.resetExport() },
            title = { Text("Falha ao exportar") },
            text = { Text(s.message) },
            confirmButton = { TextButton(onClick = { vm.resetExport() }) { Text("OK") } }
        )
        ExportState.Idle -> {}
    }
}

@Composable
private fun <T> Chips(list: List<T>, sel: T, label: (T) -> String, onPick: (T) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(list) { FilterChip(selected = it == sel, onClick = { onPick(it) }, label = { Text(label(it)) }) }
    }
}

@Composable
private fun <T> PickDialog(
    title: String, list: List<T>, sel: T, label: (T) -> String, onPick: (T) -> Unit, onClose: () -> Unit
) = AlertDialog(
    onDismissRequest = onClose,
    title = { Text(title) },
    text = { Chips(list, sel, label, onPick) },
    confirmButton = { TextButton(onClick = onClose) { Text("Fechar") } }
)
