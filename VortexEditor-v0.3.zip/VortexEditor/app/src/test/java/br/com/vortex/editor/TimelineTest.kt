package br.com.vortex.editor

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TimelineTest {
    @Test fun speedDoublesHalvesDuration() = assertEquals(5000L, Timeline.outputMs(0, 10_000, 2f))
    @Test fun slowMotionStretchesDuration() = assertEquals(8000L, Timeline.outputMs(1000, 5000, 0.5f))
    @Test fun splitInsideRangeWorks() = assertEquals(4000L, Timeline.splitPoint(0, 10_000, 4000))
    @Test fun splitTooCloseToEdgeIsRejected() {
        assertNull(Timeline.splitPoint(0, 10_000, 100))
        assertNull(Timeline.splitPoint(0, 10_000, 9_900))
    }
    @Test fun trimValidation() {
        assertTrue(Timeline.validTrim(0, 5000, 10_000))
        assertFalse(Timeline.validTrim(0, 100, 10_000))
        assertFalse(Timeline.validTrim(0, 12_000, 10_000))
    }
}
