package br.com.vortex.editor

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AiTest {
    @Test fun parsesMinecraftTenMinutes() {
        val r = PromptParser.parse("Faça esse vídeo ter 10 minutos com estilo de edição do JP Plays de Minecraft")
        assertEquals(600_000L, r.targetMs)
        assertEquals(StylePreset.GAMEPLAY, r.preset)
    }

    @Test fun parsesShortInSeconds() {
        val r = PromptParser.parse("quero um short de 30 segundos")
        assertEquals(30_000L, r.targetMs)
        assertEquals(StylePreset.SHORTS, r.preset)
    }

    @Test fun noDurationMeansNoTarget() = assertNull(PromptParser.parse("estilo vlog").targetMs)

    @Test fun plannerRespectsTargetAndOrder() {
        val energy = FloatArray(2400) { if ((it / 40) % 2 == 0) 0.3f else 0.001f }
        val req = StyleRequest(60_000L, StylePreset.GAMEPLAY, emptyList())
        val plan = Planner.plan(energy, 250L, 600_000L, req)
        assertTrue(plan.outputMs <= 60_000L)
        assertTrue(plan.outputMs >= 45_000L)
        assertTrue(plan.segments.zipWithNext().all { (a, b) -> a.endMs <= b.startMs })
    }

    @Test fun silentAudioFallsBackToWholeVideo() {
        val plan = Planner.plan(FloatArray(100), 250L, 25_000L, StyleRequest(null, StylePreset.VLOG, emptyList()))
        assertEquals(1, plan.segments.size)
    }
}
